--
-- PostgreSQL database dump
--

-- Dumped from database version 9.5.5
-- Dumped by pg_dump version 9.5.5

-- Started on 2016-11-30 15:42:32 CET

SET statement_timeout = 0;
SET lock_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SET check_function_bodies = false;
SET client_min_messages = warning;

--
-- TOC entry 11 (class 2615 OID 20496)
-- Name: sensorweb2; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA sensorweb2;


ALTER SCHEMA sensorweb2 OWNER TO postgres;

--
-- TOC entry 3914 (class 0 OID 0)
-- Dependencies: 11
-- Name: SCHEMA sensorweb2; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON SCHEMA sensorweb2 IS 'Datenbestand SensorWeb 2';


SET search_path = sensorweb2, pg_catalog;

--
-- TOC entry 1505 (class 1255 OID 20497)
-- Name: observation_del_to_series(); Type: FUNCTION; Schema: sensorweb2; Owner: postgres
--

CREATE FUNCTION observation_del_to_series() RETURNS trigger
    LANGUAGE plpgsql SECURITY DEFINER
    AS $$
DECLARE

  c1 CURSOR FOR
    SELECT
      first_time_stamp,
      first_numeric_value,
      last_time_stamp,
      last_numeric_value
    FROM sensorweb2.series
    WHERE pkid = OLD.series_pkid;

  first_ts TIMESTAMP;
  first_val NUMERIC;
  last_ts TIMESTAMP;
  last_val NUMERIC;

  max_ts TIMESTAMP;
  max_val NUMERIC;
  min_ts TIMESTAMP;
  min_val NUMERIC;

BEGIN

  -- series abfragen
  OPEN c1;
  FETCH c1 INTO first_ts, first_val, last_ts, last_val;

  -- Zeitpunkte und Werte vergleichen
  CASE

    -- Geloeschter Zeitpunkt ist der letzte
    WHEN OLD.time_stamp = last_ts THEN
      -- Vorangehenden Zeitpunkt ermitteln
      max_ts := NULL;
      SELECT MAX(time_stamp)
      INTO max_ts
      FROM sensorweb2.observation
      WHERE series_pkid = OLD.series_pkid;
      IF max_ts IS NULL THEN
        -- Es gibt keinen vorangehenden Zeitpunkt
        UPDATE sensorweb2.series SET
          last_time_stamp = NULL,
          last_numeric_value = NULL
        WHERE CURRENT OF c1;
      ELSE
        -- Wert des vorangehenden Zeitpunktes ermitteln
        SELECT numeric_value
        INTO max_val
        FROM sensorweb2.observation
        WHERE series_pkid = OLD.series_pkid
          AND time_stamp = max_ts;
        -- series aktualisieren
        UPDATE sensorweb2.series SET
          last_time_stamp = max_ts,
          last_numeric_value = max_val
        WHERE CURRENT OF c1;
      END IF;

    -- Geloeschter Zeitpunkt ist der erste
    WHEN OLD.time_stamp = first_ts THEN
      -- Nachfolgenden Zeitpunkt ermitteln
      min_ts := NULL;
      SELECT MIN(time_stamp)
      INTO min_ts
      FROM sensorweb2.observation
      WHERE series_pkid = OLD.series_pkid;
      IF min_ts IS NULL THEN
        -- Es gibt keinen nachfolgenden Zeitpunkt
        UPDATE sensorweb2.series SET
          first_time_stamp = NULL,
          first_numeric_value = NULL
        WHERE CURRENT OF c1;
      ELSE
        -- Wert des nachfolgenden Zeitpunktes ermitteln
        SELECT numeric_value
        INTO min_val
        FROM sensorweb2.observation
        WHERE series_pkid = OLD.series_pkid
          AND time_stamp = min_ts;
        -- series aktualisieren
        UPDATE sensorweb2.series SET
          first_time_stamp = min_ts,
          first_numeric_value = min_val
        WHERE CURRENT OF c1;
      END IF;

    -- Geloeschter Zeitpunkt ist der einzig verbliebene
    WHEN OLD.time_stamp = last_ts AND OLD.time_stamp = first_ts THEN
      -- Vorangehenden Zeitpunkt ermitteln (zur Sicherheit)
      max_ts := NULL;
      min_ts := NULL;
      SELECT MAX(time_stamp), MIN(time_stamp)
      INTO max_ts, min_ts
      FROM sensorweb2.observation
      WHERE series_pkid = OLD.series_pkid;
      IF max_ts IS NULL AND min_ts IS NULL THEN
        -- Es gibt keinen Zeitpunkt mehr
        UPDATE sensorweb2.series SET
          last_time_stamp = NULL,
          last_numeric_value = NULL,
          first_time_stamp = NULL,
          first_numeric_value = NULL
        WHERE CURRENT OF c1;
      ELSE
        -- Zeitpunkte speichern
        SELECT numeric_value
        INTO max_val
        FROM sensorweb2.observation
        WHERE series_pkid = OLD.series_pkid
          AND time_stamp = max_ts;
        SELECT numeric_value
        INTO min_val
        FROM sensorweb2.observation
        WHERE series_pkid = OLD.series_pkid
          AND time_stamp = max_ts;
        -- series aktualisieren
        UPDATE sensorweb2.series SET
          last_time_stamp = max_ts,
          last_numeric_value = max_val,
          first_time_stamp = min_ts,
          first_numeric_value = min_val
        WHERE CURRENT OF c1;
      END IF;

    ELSE NULL;

  END CASE;

  CLOSE c1;
  RETURN NEW;

END
$$;


ALTER FUNCTION sensorweb2.observation_del_to_series() OWNER TO postgres;

--
-- TOC entry 3915 (class 0 OID 0)
-- Dependencies: 1505
-- Name: FUNCTION observation_del_to_series(); Type: COMMENT; Schema: sensorweb2; Owner: postgres
--

COMMENT ON FUNCTION observation_del_to_series() IS 'delete in observation changes the first/last timestamps and values in series (tt-2014-03-18)';


--
-- TOC entry 1506 (class 1255 OID 20498)
-- Name: observation_ins_upd_to_series(); Type: FUNCTION; Schema: sensorweb2; Owner: postgres
--

CREATE FUNCTION observation_ins_upd_to_series() RETURNS trigger
    LANGUAGE plpgsql SECURITY DEFINER
    AS $$
DECLARE

  c1 CURSOR FOR
    SELECT
      first_time_stamp,
      first_numeric_value,
      last_time_stamp,
      last_numeric_value
    FROM sensorweb2.series
    WHERE pkid = NEW.series_pkid;

  first_ts TIMESTAMP;
  first_val NUMERIC;
  last_ts TIMESTAMP;
  last_val NUMERIC;

BEGIN

  -- series abfragen
  OPEN c1;
  FETCH c1 INTO first_ts, first_val, last_ts, last_val;

  -- Zeitpunkte und Werte vergleichen
  CASE

    -- Erster Eintrag in series => alle Felder fuellen
    WHEN first_ts IS NULL AND last_ts IS NULL THEN
      UPDATE sensorweb2.series SET
        first_time_stamp = NEW.time_stamp,
        first_numeric_value = NEW.numeric_value,
        last_time_stamp = NEW.time_stamp,
        last_numeric_value = NEW.numeric_value
      WHERE CURRENT OF c1;

    -- Erster Eintrag ist gefuellt, letzter Eintrag ist nicht gefuellt (sollte eigentlich nicht vorkommen)
    WHEN first_ts IS NULL AND last_ts IS NOT NULL THEN
      UPDATE sensorweb2.series SET
        first_time_stamp = NEW.time_stamp,
        first_numeric_value = NEW.numeric_value
      WHERE CURRENT OF c1;

    -- Erster Eintrag ist nicht gefuellt, letzter Eintrag ist gefuellt (sollte eigentlich nicht vorkommen)
    WHEN first_ts IS NOT NULL AND last_ts IS NULL THEN
      UPDATE sensorweb2.series SET
        last_time_stamp = NEW.time_stamp,
        last_numeric_value = NEW.numeric_value
      WHERE CURRENT OF c1;

    -- Neuer Zeitpunkt liegt nach dem bisher letzten Zeitpunkt => last-Felder aktualisieren
    WHEN NEW.time_stamp > last_ts THEN
      UPDATE sensorweb2.series SET
        last_time_stamp = NEW.time_stamp,
        last_numeric_value = NEW.numeric_value
      WHERE CURRENT OF c1;

    -- Letzter Zeitpunkt ist gleich, aber Wert ist geaendert => last-value-Feld aktualisieren
    WHEN NEW.time_stamp = last_ts AND NEW.numeric_value <> last_val THEN
      UPDATE sensorweb2.series SET
        last_numeric_value = NEW.numeric_value
      WHERE CURRENT OF c1;

    -- Neuer Zeitpunkt liegt vor dem bisher ersten Zeitpunkt => first-Felder aktualisieren
    WHEN NEW.time_stamp < first_ts THEN
      UPDATE sensorweb2.series SET
        first_time_stamp = NEW.time_stamp,
        first_numeric_value = NEW.numeric_value
      WHERE CURRENT OF c1;

    -- Erster Zeitpunkt ist gleich, aber Wert ist geaendert => first-value-Feld aktualisieren
    WHEN NEW.time_stamp = first_ts AND NEW.numeric_value <> first_val THEN
      UPDATE sensorweb2.series SET
        first_numeric_value = NEW.numeric_value
      WHERE CURRENT OF c1;

    ELSE NULL;

  END CASE;

  CLOSE c1;
  RETURN NEW;

END
$$;


ALTER FUNCTION sensorweb2.observation_ins_upd_to_series() OWNER TO postgres;

--
-- TOC entry 3916 (class 0 OID 0)
-- Dependencies: 1506
-- Name: FUNCTION observation_ins_upd_to_series(); Type: COMMENT; Schema: sensorweb2; Owner: postgres
--

COMMENT ON FUNCTION observation_ins_upd_to_series() IS 'insert or update in observation updates the first/last timestamps and values in series (2014-03-18)';


--
-- TOC entry 1507 (class 1255 OID 20499)
-- Name: observation_sync_derived(); Type: FUNCTION; Schema: sensorweb2; Owner: postgres
--

CREATE FUNCTION observation_sync_derived() RETURNS trigger
    LANGUAGE plpgsql SECURITY DEFINER
    AS $$

DECLARE



  op CHAR(1);

  sd RECORD;

  pkid_base INTEGER;

  newval NUMERIC(20,10);



BEGIN



  op := UPPER(LEFT(TG_OP, 1));  -- I/U/D fuer Insert/Update/Delete



  IF op = 'D' THEN

    pkid_base := OLD.series_pkid;

  END IF;

  IF op = 'I' OR op = 'U' THEN

    pkid_base := NEW.series_pkid;

  END IF;



  FOR sd IN

    SELECT

      series_pkid_derived,

      formula

    FROM sensorweb2.series_derived

    WHERE series_pkid_base = pkid_base

  LOOP

    IF op = 'D' OR op = 'U' THEN

      -- 1. Schritt: Delete oder Update: Alte Observation loeschen

      DELETE FROM sensorweb2.observation

        WHERE series_pkid = sd.series_pkid_derived

          AND time_stamp = OLD.time_stamp;

    END IF;

    IF op = 'I' OR op = 'U' THEN

      -- 2. Schritt: Insert oder Update: Neue Observation speichern

      EXECUTE 'SELECT ' || REPLACE(sd.formula, '{x}', NEW.numeric_value::TEXT) INTO newval;

      INSERT INTO sensorweb2.observation (time_stamp, series_pkid, numeric_value, result_time)

        VALUES (NEW.time_stamp, sd.series_pkid_derived, newval, NEW.time_stamp);

    END IF;

  END LOOP;



  RETURN NEW;



END

$$;


ALTER FUNCTION sensorweb2.observation_sync_derived() OWNER TO postgres;

--
-- TOC entry 3917 (class 0 OID 0)
-- Dependencies: 1507
-- Name: FUNCTION observation_sync_derived(); Type: COMMENT; Schema: sensorweb2; Owner: postgres
--

COMMENT ON FUNCTION observation_sync_derived() IS 'synchronize derived observations (tt-2016-05-20)';


SET default_tablespace = '';

SET default_with_oids = false;

--
-- TOC entry 206 (class 1259 OID 20500)
-- Name: category; Type: TABLE; Schema: sensorweb2; Owner: postgres
--

CREATE TABLE category (
    pkid integer NOT NULL,
    category_id character varying(100) NOT NULL,
    category_name character varying(100),
    description character varying(100)
);


ALTER TABLE category OWNER TO postgres;

--
-- TOC entry 3918 (class 0 OID 0)
-- Dependencies: 206
-- Name: TABLE category; Type: COMMENT; Schema: sensorweb2; Owner: postgres
--

COMMENT ON TABLE category IS 'represents categories, which classifies series';


--
-- TOC entry 3919 (class 0 OID 0)
-- Dependencies: 206
-- Name: COLUMN category.pkid; Type: COMMENT; Schema: sensorweb2; Owner: postgres
--

COMMENT ON COLUMN category.pkid IS 'serial primary key';


--
-- TOC entry 3920 (class 0 OID 0)
-- Dependencies: 206
-- Name: COLUMN category.category_id; Type: COMMENT; Schema: sensorweb2; Owner: postgres
--

COMMENT ON COLUMN category.category_id IS 'identification of the category without special chars';


--
-- TOC entry 3921 (class 0 OID 0)
-- Dependencies: 206
-- Name: COLUMN category.category_name; Type: COMMENT; Schema: sensorweb2; Owner: postgres
--

COMMENT ON COLUMN category.category_name IS 'default name of the category';


--
-- TOC entry 3922 (class 0 OID 0)
-- Dependencies: 206
-- Name: COLUMN category.description; Type: COMMENT; Schema: sensorweb2; Owner: postgres
--

COMMENT ON COLUMN category.description IS 'default description of the category';


--
-- TOC entry 207 (class 1259 OID 20503)
-- Name: category_i18n; Type: TABLE; Schema: sensorweb2; Owner: postgres
--

CREATE TABLE category_i18n (
    pkid integer NOT NULL,
    category_pkid integer NOT NULL,
    locale character varying(10) NOT NULL,
    name character varying(100),
    description character varying(100)
);


ALTER TABLE category_i18n OWNER TO postgres;

--
-- TOC entry 3923 (class 0 OID 0)
-- Dependencies: 207
-- Name: TABLE category_i18n; Type: COMMENT; Schema: sensorweb2; Owner: postgres
--

COMMENT ON TABLE category_i18n IS 'internationalization of categories';


--
-- TOC entry 3924 (class 0 OID 0)
-- Dependencies: 207
-- Name: COLUMN category_i18n.pkid; Type: COMMENT; Schema: sensorweb2; Owner: postgres
--

COMMENT ON COLUMN category_i18n.pkid IS 'serial primary key';


--
-- TOC entry 3925 (class 0 OID 0)
-- Dependencies: 207
-- Name: COLUMN category_i18n.category_pkid; Type: COMMENT; Schema: sensorweb2; Owner: postgres
--

COMMENT ON COLUMN category_i18n.category_pkid IS 'Id of the category the record belongs to';


--
-- TOC entry 3926 (class 0 OID 0)
-- Dependencies: 207
-- Name: COLUMN category_i18n.locale; Type: COMMENT; Schema: sensorweb2; Owner: postgres
--

COMMENT ON COLUMN category_i18n.locale IS 'language identifier and region identifier';


--
-- TOC entry 3927 (class 0 OID 0)
-- Dependencies: 207
-- Name: COLUMN category_i18n.name; Type: COMMENT; Schema: sensorweb2; Owner: postgres
--

COMMENT ON COLUMN category_i18n.name IS 'name of the category in locale''s language';


--
-- TOC entry 3928 (class 0 OID 0)
-- Dependencies: 207
-- Name: COLUMN category_i18n.description; Type: COMMENT; Schema: sensorweb2; Owner: postgres
--

COMMENT ON COLUMN category_i18n.description IS 'description of the category in locale''s language';


--
-- TOC entry 208 (class 1259 OID 20506)
-- Name: category_i18n_pkid_seq; Type: SEQUENCE; Schema: sensorweb2; Owner: postgres
--

CREATE SEQUENCE category_i18n_pkid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE category_i18n_pkid_seq OWNER TO postgres;

--
-- TOC entry 3929 (class 0 OID 0)
-- Dependencies: 208
-- Name: category_i18n_pkid_seq; Type: SEQUENCE OWNED BY; Schema: sensorweb2; Owner: postgres
--

ALTER SEQUENCE category_i18n_pkid_seq OWNED BY category_i18n.pkid;


--
-- TOC entry 209 (class 1259 OID 20508)
-- Name: category_pkid_seq; Type: SEQUENCE; Schema: sensorweb2; Owner: postgres
--

CREATE SEQUENCE category_pkid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE category_pkid_seq OWNER TO postgres;

--
-- TOC entry 3930 (class 0 OID 0)
-- Dependencies: 209
-- Name: category_pkid_seq; Type: SEQUENCE OWNED BY; Schema: sensorweb2; Owner: postgres
--

ALTER SEQUENCE category_pkid_seq OWNED BY category.pkid;


--
-- TOC entry 210 (class 1259 OID 20510)
-- Name: cluster; Type: TABLE; Schema: sensorweb2; Owner: postgres
--

CREATE TABLE cluster (
    pkid integer NOT NULL,
    cluster_id character varying(100) NOT NULL,
    cluster_name character varying(100),
    description character varying(100)
);


ALTER TABLE cluster OWNER TO postgres;

--
-- TOC entry 3931 (class 0 OID 0)
-- Dependencies: 210
-- Name: TABLE cluster; Type: COMMENT; Schema: sensorweb2; Owner: postgres
--

COMMENT ON TABLE cluster IS 'represents clusters, which bundels series';


--
-- TOC entry 3932 (class 0 OID 0)
-- Dependencies: 210
-- Name: COLUMN cluster.pkid; Type: COMMENT; Schema: sensorweb2; Owner: postgres
--

COMMENT ON COLUMN cluster.pkid IS 'serial primary key';


--
-- TOC entry 3933 (class 0 OID 0)
-- Dependencies: 210
-- Name: COLUMN cluster.cluster_id; Type: COMMENT; Schema: sensorweb2; Owner: postgres
--

COMMENT ON COLUMN cluster.cluster_id IS 'identification of the cluster without special chars';


--
-- TOC entry 3934 (class 0 OID 0)
-- Dependencies: 210
-- Name: COLUMN cluster.cluster_name; Type: COMMENT; Schema: sensorweb2; Owner: postgres
--

COMMENT ON COLUMN cluster.cluster_name IS 'default name of the cluster';


--
-- TOC entry 3935 (class 0 OID 0)
-- Dependencies: 210
-- Name: COLUMN cluster.description; Type: COMMENT; Schema: sensorweb2; Owner: postgres
--

COMMENT ON COLUMN cluster.description IS 'default description of the cluster';


--
-- TOC entry 211 (class 1259 OID 20513)
-- Name: cluster_pkid_seq; Type: SEQUENCE; Schema: sensorweb2; Owner: postgres
--

CREATE SEQUENCE cluster_pkid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE cluster_pkid_seq OWNER TO postgres;

--
-- TOC entry 3936 (class 0 OID 0)
-- Dependencies: 211
-- Name: cluster_pkid_seq; Type: SEQUENCE OWNED BY; Schema: sensorweb2; Owner: postgres
--

ALTER SEQUENCE cluster_pkid_seq OWNED BY cluster.pkid;


--
-- TOC entry 212 (class 1259 OID 20515)
-- Name: event; Type: TABLE; Schema: sensorweb2; Owner: postgres
--

CREATE TABLE event (
    pkid integer NOT NULL,
    rule_pkid integer NOT NULL,
    time_stamp timestamp without time zone NOT NULL,
    numeric_value numeric(20,10) NOT NULL,
    previous_time_stamp timestamp without time zone NOT NULL,
    previous_numeric_value numeric(20,10) NOT NULL
);


ALTER TABLE event OWNER TO postgres;

--
-- TOC entry 3937 (class 0 OID 0)
-- Dependencies: 212
-- Name: TABLE event; Type: COMMENT; Schema: sensorweb2; Owner: postgres
--

COMMENT ON TABLE event IS 'registered events';


--
-- TOC entry 3938 (class 0 OID 0)
-- Dependencies: 212
-- Name: COLUMN event.pkid; Type: COMMENT; Schema: sensorweb2; Owner: postgres
--

COMMENT ON COLUMN event.pkid IS 'serial primary key';


--
-- TOC entry 3939 (class 0 OID 0)
-- Dependencies: 212
-- Name: COLUMN event.rule_pkid; Type: COMMENT; Schema: sensorweb2; Owner: postgres
--

COMMENT ON COLUMN event.rule_pkid IS 'primary key of the rule the event is deduced from';


--
-- TOC entry 3940 (class 0 OID 0)
-- Dependencies: 212
-- Name: COLUMN event.time_stamp; Type: COMMENT; Schema: sensorweb2; Owner: postgres
--

COMMENT ON COLUMN event.time_stamp IS 'point in time at which the observation happens';


--
-- TOC entry 3941 (class 0 OID 0)
-- Dependencies: 212
-- Name: COLUMN event.numeric_value; Type: COMMENT; Schema: sensorweb2; Owner: postgres
--

COMMENT ON COLUMN event.numeric_value IS 'observed value';


--
-- TOC entry 3942 (class 0 OID 0)
-- Dependencies: 212
-- Name: COLUMN event.previous_time_stamp; Type: COMMENT; Schema: sensorweb2; Owner: postgres
--

COMMENT ON COLUMN event.previous_time_stamp IS 'point in time at which the previous observation happens';


--
-- TOC entry 3943 (class 0 OID 0)
-- Dependencies: 212
-- Name: COLUMN event.previous_numeric_value; Type: COMMENT; Schema: sensorweb2; Owner: postgres
--

COMMENT ON COLUMN event.previous_numeric_value IS 'previous observed value';


--
-- TOC entry 213 (class 1259 OID 20518)
-- Name: event_pkid_seq; Type: SEQUENCE; Schema: sensorweb2; Owner: postgres
--

CREATE SEQUENCE event_pkid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE event_pkid_seq OWNER TO postgres;

--
-- TOC entry 3944 (class 0 OID 0)
-- Dependencies: 213
-- Name: event_pkid_seq; Type: SEQUENCE OWNED BY; Schema: sensorweb2; Owner: postgres
--

ALTER SEQUENCE event_pkid_seq OWNED BY event.pkid;


--
-- TOC entry 214 (class 1259 OID 20520)
-- Name: feature_of_interest; Type: TABLE; Schema: sensorweb2; Owner: postgres
--

CREATE TABLE feature_of_interest (
    pkid integer NOT NULL,
    feature_of_interest_id character varying(100) NOT NULL,
    feature_of_interest_name character varying(100) NOT NULL,
    geom public.geometry,
    feature_class character varying(100),
    reference_wv_id integer NOT NULL,
    description character varying(100)
);


ALTER TABLE feature_of_interest OWNER TO postgres;

--
-- TOC entry 3945 (class 0 OID 0)
-- Dependencies: 214
-- Name: TABLE feature_of_interest; Type: COMMENT; Schema: sensorweb2; Owner: postgres
--

COMMENT ON TABLE feature_of_interest IS 'represents the feature of interest of an observation';


--
-- TOC entry 3946 (class 0 OID 0)
-- Dependencies: 214
-- Name: COLUMN feature_of_interest.pkid; Type: COMMENT; Schema: sensorweb2; Owner: postgres
--

COMMENT ON COLUMN feature_of_interest.pkid IS 'serial primary key';


--
-- TOC entry 3947 (class 0 OID 0)
-- Dependencies: 214
-- Name: COLUMN feature_of_interest.feature_of_interest_id; Type: COMMENT; Schema: sensorweb2; Owner: postgres
--

COMMENT ON COLUMN feature_of_interest.feature_of_interest_id IS 'identification of the feature of interest without special chars';


--
-- TOC entry 3948 (class 0 OID 0)
-- Dependencies: 214
-- Name: COLUMN feature_of_interest.feature_of_interest_name; Type: COMMENT; Schema: sensorweb2; Owner: postgres
--

COMMENT ON COLUMN feature_of_interest.feature_of_interest_name IS 'default name of the feature of interest';


--
-- TOC entry 3949 (class 0 OID 0)
-- Dependencies: 214
-- Name: COLUMN feature_of_interest.geom; Type: COMMENT; Schema: sensorweb2; Owner: postgres
--

COMMENT ON COLUMN feature_of_interest.geom IS 'geometry of the feature of interest';


--
-- TOC entry 3950 (class 0 OID 0)
-- Dependencies: 214
-- Name: COLUMN feature_of_interest.feature_class; Type: COMMENT; Schema: sensorweb2; Owner: postgres
--

COMMENT ON COLUMN feature_of_interest.feature_class IS 'name of the feature class the feature of interest is coming from';


--
-- TOC entry 3951 (class 0 OID 0)
-- Dependencies: 214
-- Name: COLUMN feature_of_interest.reference_wv_id; Type: COMMENT; Schema: sensorweb2; Owner: postgres
--

COMMENT ON COLUMN feature_of_interest.reference_wv_id IS 'internal unique reference number';


--
-- TOC entry 3952 (class 0 OID 0)
-- Dependencies: 214
-- Name: COLUMN feature_of_interest.description; Type: COMMENT; Schema: sensorweb2; Owner: postgres
--

COMMENT ON COLUMN feature_of_interest.description IS 'default description of the feature of interest';


--
-- TOC entry 215 (class 1259 OID 20526)
-- Name: feature_of_interest_i18n; Type: TABLE; Schema: sensorweb2; Owner: postgres
--

CREATE TABLE feature_of_interest_i18n (
    pkid integer NOT NULL,
    feature_of_interest_pkid integer NOT NULL,
    locale character varying(10) NOT NULL,
    name character varying(100),
    description character varying(100)
);


ALTER TABLE feature_of_interest_i18n OWNER TO postgres;

--
-- TOC entry 3953 (class 0 OID 0)
-- Dependencies: 215
-- Name: TABLE feature_of_interest_i18n; Type: COMMENT; Schema: sensorweb2; Owner: postgres
--

COMMENT ON TABLE feature_of_interest_i18n IS 'internationalization of feature of interests';


--
-- TOC entry 3954 (class 0 OID 0)
-- Dependencies: 215
-- Name: COLUMN feature_of_interest_i18n.pkid; Type: COMMENT; Schema: sensorweb2; Owner: postgres
--

COMMENT ON COLUMN feature_of_interest_i18n.pkid IS 'serial primary key';


--
-- TOC entry 3955 (class 0 OID 0)
-- Dependencies: 215
-- Name: COLUMN feature_of_interest_i18n.feature_of_interest_pkid; Type: COMMENT; Schema: sensorweb2; Owner: postgres
--

COMMENT ON COLUMN feature_of_interest_i18n.feature_of_interest_pkid IS 'Id of the feature of interest the record belongs to';


--
-- TOC entry 3956 (class 0 OID 0)
-- Dependencies: 215
-- Name: COLUMN feature_of_interest_i18n.locale; Type: COMMENT; Schema: sensorweb2; Owner: postgres
--

COMMENT ON COLUMN feature_of_interest_i18n.locale IS 'language identifier and region identifier';


--
-- TOC entry 3957 (class 0 OID 0)
-- Dependencies: 215
-- Name: COLUMN feature_of_interest_i18n.name; Type: COMMENT; Schema: sensorweb2; Owner: postgres
--

COMMENT ON COLUMN feature_of_interest_i18n.name IS 'name of the feature of interest in locale''s language';


--
-- TOC entry 3958 (class 0 OID 0)
-- Dependencies: 215
-- Name: COLUMN feature_of_interest_i18n.description; Type: COMMENT; Schema: sensorweb2; Owner: postgres
--

COMMENT ON COLUMN feature_of_interest_i18n.description IS 'description of the feature of interest in locale''s language';


--
-- TOC entry 216 (class 1259 OID 20529)
-- Name: feature_of_interest_i18n_pkid_seq; Type: SEQUENCE; Schema: sensorweb2; Owner: postgres
--

CREATE SEQUENCE feature_of_interest_i18n_pkid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE feature_of_interest_i18n_pkid_seq OWNER TO postgres;

--
-- TOC entry 3959 (class 0 OID 0)
-- Dependencies: 216
-- Name: feature_of_interest_i18n_pkid_seq; Type: SEQUENCE OWNED BY; Schema: sensorweb2; Owner: postgres
--

ALTER SEQUENCE feature_of_interest_i18n_pkid_seq OWNED BY feature_of_interest_i18n.pkid;


--
-- TOC entry 217 (class 1259 OID 20531)
-- Name: feature_of_interest_pkid_seq; Type: SEQUENCE; Schema: sensorweb2; Owner: postgres
--

CREATE SEQUENCE feature_of_interest_pkid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE feature_of_interest_pkid_seq OWNER TO postgres;

--
-- TOC entry 3960 (class 0 OID 0)
-- Dependencies: 217
-- Name: feature_of_interest_pkid_seq; Type: SEQUENCE OWNED BY; Schema: sensorweb2; Owner: postgres
--

ALTER SEQUENCE feature_of_interest_pkid_seq OWNED BY feature_of_interest.pkid;


--
-- TOC entry 251 (class 1259 OID 20869)
-- Name: hibernate_sequence; Type: SEQUENCE; Schema: sensorweb2; Owner: postgres
--

CREATE SEQUENCE hibernate_sequence
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE hibernate_sequence OWNER TO postgres;

--
-- TOC entry 218 (class 1259 OID 20533)
-- Name: observation; Type: TABLE; Schema: sensorweb2; Owner: postgres
--

CREATE TABLE observation (
    pkid integer NOT NULL,
    time_stamp timestamp without time zone NOT NULL,
    series_pkid integer NOT NULL,
    numeric_value numeric(20,10),
    time_stamp_insert timestamp without time zone DEFAULT now(),
    comment character varying(100)
);


ALTER TABLE observation OWNER TO postgres;

--
-- TOC entry 3961 (class 0 OID 0)
-- Dependencies: 218
-- Name: TABLE observation; Type: COMMENT; Schema: sensorweb2; Owner: postgres
--

COMMENT ON TABLE observation IS 'represents observations';


--
-- TOC entry 3962 (class 0 OID 0)
-- Dependencies: 218
-- Name: COLUMN observation.pkid; Type: COMMENT; Schema: sensorweb2; Owner: postgres
--

COMMENT ON COLUMN observation.pkid IS 'serial primary key';


--
-- TOC entry 3963 (class 0 OID 0)
-- Dependencies: 218
-- Name: COLUMN observation.time_stamp; Type: COMMENT; Schema: sensorweb2; Owner: postgres
--

COMMENT ON COLUMN observation.time_stamp IS 'point in time at which the observation happens';


--
-- TOC entry 3964 (class 0 OID 0)
-- Dependencies: 218
-- Name: COLUMN observation.series_pkid; Type: COMMENT; Schema: sensorweb2; Owner: postgres
--

COMMENT ON COLUMN observation.series_pkid IS 'primary key of the series the observed value belongs to';


--
-- TOC entry 3965 (class 0 OID 0)
-- Dependencies: 218
-- Name: COLUMN observation.numeric_value; Type: COMMENT; Schema: sensorweb2; Owner: postgres
--

COMMENT ON COLUMN observation.numeric_value IS 'observed value';


--
-- TOC entry 3966 (class 0 OID 0)
-- Dependencies: 218
-- Name: COLUMN observation.time_stamp_insert; Type: COMMENT; Schema: sensorweb2; Owner: postgres
--

COMMENT ON COLUMN observation.time_stamp_insert IS 'point in time at which the observation is stored in the table';


--
-- TOC entry 3967 (class 0 OID 0)
-- Dependencies: 218
-- Name: COLUMN observation.comment; Type: COMMENT; Schema: sensorweb2; Owner: postgres
--

COMMENT ON COLUMN observation.comment IS 'additional information about the observed value';


--
-- TOC entry 219 (class 1259 OID 20537)
-- Name: observation_pkid_seq; Type: SEQUENCE; Schema: sensorweb2; Owner: postgres
--

CREATE SEQUENCE observation_pkid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE observation_pkid_seq OWNER TO postgres;

--
-- TOC entry 3968 (class 0 OID 0)
-- Dependencies: 219
-- Name: observation_pkid_seq; Type: SEQUENCE OWNED BY; Schema: sensorweb2; Owner: postgres
--

ALTER SEQUENCE observation_pkid_seq OWNED BY observation.pkid;


--
-- TOC entry 220 (class 1259 OID 20539)
-- Name: phenomenon; Type: TABLE; Schema: sensorweb2; Owner: postgres
--

CREATE TABLE phenomenon (
    pkid integer NOT NULL,
    phenomenon_id character varying(100) NOT NULL,
    phenomenon_name character varying(100),
    description character varying(100)
);


ALTER TABLE phenomenon OWNER TO postgres;

--
-- TOC entry 3969 (class 0 OID 0)
-- Dependencies: 220
-- Name: TABLE phenomenon; Type: COMMENT; Schema: sensorweb2; Owner: postgres
--

COMMENT ON TABLE phenomenon IS 'represents phenomena';


--
-- TOC entry 3970 (class 0 OID 0)
-- Dependencies: 220
-- Name: COLUMN phenomenon.pkid; Type: COMMENT; Schema: sensorweb2; Owner: postgres
--

COMMENT ON COLUMN phenomenon.pkid IS 'serial primary key';


--
-- TOC entry 3971 (class 0 OID 0)
-- Dependencies: 220
-- Name: COLUMN phenomenon.description; Type: COMMENT; Schema: sensorweb2; Owner: postgres
--

COMMENT ON COLUMN phenomenon.description IS 'default description of the phenomenon';


--
-- TOC entry 221 (class 1259 OID 20542)
-- Name: phenomenon_i18n; Type: TABLE; Schema: sensorweb2; Owner: postgres
--

CREATE TABLE phenomenon_i18n (
    pkid integer NOT NULL,
    phenomenon_pkid integer NOT NULL,
    locale character varying(10) NOT NULL,
    name character varying(100),
    description character varying(100)
);


ALTER TABLE phenomenon_i18n OWNER TO postgres;

--
-- TOC entry 3972 (class 0 OID 0)
-- Dependencies: 221
-- Name: TABLE phenomenon_i18n; Type: COMMENT; Schema: sensorweb2; Owner: postgres
--

COMMENT ON TABLE phenomenon_i18n IS 'internationalization of phenomenons';


--
-- TOC entry 3973 (class 0 OID 0)
-- Dependencies: 221
-- Name: COLUMN phenomenon_i18n.pkid; Type: COMMENT; Schema: sensorweb2; Owner: postgres
--

COMMENT ON COLUMN phenomenon_i18n.pkid IS 'serial primary key';


--
-- TOC entry 3974 (class 0 OID 0)
-- Dependencies: 221
-- Name: COLUMN phenomenon_i18n.phenomenon_pkid; Type: COMMENT; Schema: sensorweb2; Owner: postgres
--

COMMENT ON COLUMN phenomenon_i18n.phenomenon_pkid IS 'Id of the phenomenon the record belongs to';


--
-- TOC entry 3975 (class 0 OID 0)
-- Dependencies: 221
-- Name: COLUMN phenomenon_i18n.locale; Type: COMMENT; Schema: sensorweb2; Owner: postgres
--

COMMENT ON COLUMN phenomenon_i18n.locale IS 'language identifier and region identifier';


--
-- TOC entry 3976 (class 0 OID 0)
-- Dependencies: 221
-- Name: COLUMN phenomenon_i18n.name; Type: COMMENT; Schema: sensorweb2; Owner: postgres
--

COMMENT ON COLUMN phenomenon_i18n.name IS 'name of the phenomenon in locale''s language';


--
-- TOC entry 3977 (class 0 OID 0)
-- Dependencies: 221
-- Name: COLUMN phenomenon_i18n.description; Type: COMMENT; Schema: sensorweb2; Owner: postgres
--

COMMENT ON COLUMN phenomenon_i18n.description IS 'description of the phenomenon in locale''s language';


--
-- TOC entry 222 (class 1259 OID 20545)
-- Name: phenomenon_i18n_pkid_seq; Type: SEQUENCE; Schema: sensorweb2; Owner: postgres
--

CREATE SEQUENCE phenomenon_i18n_pkid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE phenomenon_i18n_pkid_seq OWNER TO postgres;

--
-- TOC entry 3978 (class 0 OID 0)
-- Dependencies: 222
-- Name: phenomenon_i18n_pkid_seq; Type: SEQUENCE OWNED BY; Schema: sensorweb2; Owner: postgres
--

ALTER SEQUENCE phenomenon_i18n_pkid_seq OWNED BY phenomenon_i18n.pkid;


--
-- TOC entry 223 (class 1259 OID 20547)
-- Name: phenomenon_pkid_seq; Type: SEQUENCE; Schema: sensorweb2; Owner: postgres
--

CREATE SEQUENCE phenomenon_pkid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE phenomenon_pkid_seq OWNER TO postgres;

--
-- TOC entry 3979 (class 0 OID 0)
-- Dependencies: 223
-- Name: phenomenon_pkid_seq; Type: SEQUENCE OWNED BY; Schema: sensorweb2; Owner: postgres
--

ALTER SEQUENCE phenomenon_pkid_seq OWNED BY phenomenon.pkid;


--
-- TOC entry 224 (class 1259 OID 20549)
-- Name: procedure; Type: TABLE; Schema: sensorweb2; Owner: postgres
--

CREATE TABLE procedure (
    pkid integer NOT NULL,
    procedure_id character varying(100) NOT NULL,
    procedure_name character varying(100),
    description_type character varying(100),
    reference_flag smallint,
    description character varying(100)
);


ALTER TABLE procedure OWNER TO postgres;

--
-- TOC entry 3980 (class 0 OID 0)
-- Dependencies: 224
-- Name: TABLE procedure; Type: COMMENT; Schema: sensorweb2; Owner: postgres
--

COMMENT ON TABLE procedure IS 'represents the procedure which produces the observation values';


--
-- TOC entry 3981 (class 0 OID 0)
-- Dependencies: 224
-- Name: COLUMN procedure.pkid; Type: COMMENT; Schema: sensorweb2; Owner: postgres
--

COMMENT ON COLUMN procedure.pkid IS 'serial primary key';


--
-- TOC entry 3982 (class 0 OID 0)
-- Dependencies: 224
-- Name: COLUMN procedure.procedure_id; Type: COMMENT; Schema: sensorweb2; Owner: postgres
--

COMMENT ON COLUMN procedure.procedure_id IS 'identification of the procedure without special chars';


--
-- TOC entry 3983 (class 0 OID 0)
-- Dependencies: 224
-- Name: COLUMN procedure.procedure_name; Type: COMMENT; Schema: sensorweb2; Owner: postgres
--

COMMENT ON COLUMN procedure.procedure_name IS 'default name of the procedure';


--
-- TOC entry 3984 (class 0 OID 0)
-- Dependencies: 224
-- Name: COLUMN procedure.description_type; Type: COMMENT; Schema: sensorweb2; Owner: postgres
--

COMMENT ON COLUMN procedure.description_type IS 'content type of the description';


--
-- TOC entry 3985 (class 0 OID 0)
-- Dependencies: 224
-- Name: COLUMN procedure.reference_flag; Type: COMMENT; Schema: sensorweb2; Owner: postgres
--

COMMENT ON COLUMN procedure.reference_flag IS 'binary flag indicating if the procedure is a reference procedure';


--
-- TOC entry 3986 (class 0 OID 0)
-- Dependencies: 224
-- Name: COLUMN procedure.description; Type: COMMENT; Schema: sensorweb2; Owner: postgres
--

COMMENT ON COLUMN procedure.description IS 'default description of the procedure';


--
-- TOC entry 225 (class 1259 OID 20552)
-- Name: procedure_i18n; Type: TABLE; Schema: sensorweb2; Owner: postgres
--

CREATE TABLE procedure_i18n (
    pkid integer NOT NULL,
    procedure_pkid integer NOT NULL,
    locale character varying(10) NOT NULL,
    name character varying(100),
    description character varying(100)
);


ALTER TABLE procedure_i18n OWNER TO postgres;

--
-- TOC entry 3987 (class 0 OID 0)
-- Dependencies: 225
-- Name: TABLE procedure_i18n; Type: COMMENT; Schema: sensorweb2; Owner: postgres
--

COMMENT ON TABLE procedure_i18n IS 'internationalization of procedures';


--
-- TOC entry 3988 (class 0 OID 0)
-- Dependencies: 225
-- Name: COLUMN procedure_i18n.pkid; Type: COMMENT; Schema: sensorweb2; Owner: postgres
--

COMMENT ON COLUMN procedure_i18n.pkid IS 'serial primary key';


--
-- TOC entry 3989 (class 0 OID 0)
-- Dependencies: 225
-- Name: COLUMN procedure_i18n.procedure_pkid; Type: COMMENT; Schema: sensorweb2; Owner: postgres
--

COMMENT ON COLUMN procedure_i18n.procedure_pkid IS 'Id of the procedure the record belongs to';


--
-- TOC entry 3990 (class 0 OID 0)
-- Dependencies: 225
-- Name: COLUMN procedure_i18n.locale; Type: COMMENT; Schema: sensorweb2; Owner: postgres
--

COMMENT ON COLUMN procedure_i18n.locale IS 'language identifier and region identifier';


--
-- TOC entry 3991 (class 0 OID 0)
-- Dependencies: 225
-- Name: COLUMN procedure_i18n.name; Type: COMMENT; Schema: sensorweb2; Owner: postgres
--

COMMENT ON COLUMN procedure_i18n.name IS 'name of the procedure in locale''s language';


--
-- TOC entry 3992 (class 0 OID 0)
-- Dependencies: 225
-- Name: COLUMN procedure_i18n.description; Type: COMMENT; Schema: sensorweb2; Owner: postgres
--

COMMENT ON COLUMN procedure_i18n.description IS 'description of the procedure in locale''s language';


--
-- TOC entry 226 (class 1259 OID 20555)
-- Name: procedure_i18n_pkid_seq; Type: SEQUENCE; Schema: sensorweb2; Owner: postgres
--

CREATE SEQUENCE procedure_i18n_pkid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE procedure_i18n_pkid_seq OWNER TO postgres;

--
-- TOC entry 3993 (class 0 OID 0)
-- Dependencies: 226
-- Name: procedure_i18n_pkid_seq; Type: SEQUENCE OWNED BY; Schema: sensorweb2; Owner: postgres
--

ALTER SEQUENCE procedure_i18n_pkid_seq OWNED BY procedure_i18n.pkid;


--
-- TOC entry 227 (class 1259 OID 20557)
-- Name: procedure_pkid_seq; Type: SEQUENCE; Schema: sensorweb2; Owner: postgres
--

CREATE SEQUENCE procedure_pkid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE procedure_pkid_seq OWNER TO postgres;

--
-- TOC entry 3994 (class 0 OID 0)
-- Dependencies: 227
-- Name: procedure_pkid_seq; Type: SEQUENCE OWNED BY; Schema: sensorweb2; Owner: postgres
--

ALTER SEQUENCE procedure_pkid_seq OWNED BY procedure.pkid;


--
-- TOC entry 228 (class 1259 OID 20559)
-- Name: rule; Type: TABLE; Schema: sensorweb2; Owner: postgres
--

CREATE TABLE rule (
    pkid integer NOT NULL,
    series_pkid integer NOT NULL,
    threshold numeric(20,10) NOT NULL,
    trend_code numeric(2,0) NOT NULL,
    active_flag numeric(1,0) DEFAULT 0,
    CONSTRAINT rule_active_flag_check CHECK ((active_flag = ANY (ARRAY[(0)::numeric, (1)::numeric])))
);


ALTER TABLE rule OWNER TO postgres;

--
-- TOC entry 3995 (class 0 OID 0)
-- Dependencies: 228
-- Name: TABLE rule; Type: COMMENT; Schema: sensorweb2; Owner: postgres
--

COMMENT ON TABLE rule IS 'events to be checked';


--
-- TOC entry 3996 (class 0 OID 0)
-- Dependencies: 228
-- Name: COLUMN rule.pkid; Type: COMMENT; Schema: sensorweb2; Owner: postgres
--

COMMENT ON COLUMN rule.pkid IS 'serial primary key';


--
-- TOC entry 3997 (class 0 OID 0)
-- Dependencies: 228
-- Name: COLUMN rule.series_pkid; Type: COMMENT; Schema: sensorweb2; Owner: postgres
--

COMMENT ON COLUMN rule.series_pkid IS 'primary key of the series the rule belongs to';


--
-- TOC entry 3998 (class 0 OID 0)
-- Dependencies: 228
-- Name: COLUMN rule.threshold; Type: COMMENT; Schema: sensorweb2; Owner: postgres
--

COMMENT ON COLUMN rule.threshold IS 'value at which the rule is applied to';


--
-- TOC entry 3999 (class 0 OID 0)
-- Dependencies: 228
-- Name: COLUMN rule.trend_code; Type: COMMENT; Schema: sensorweb2; Owner: postgres
--

COMMENT ON COLUMN rule.trend_code IS 'primary key of the trend code the rule belongs to';


--
-- TOC entry 4000 (class 0 OID 0)
-- Dependencies: 228
-- Name: COLUMN rule.active_flag; Type: COMMENT; Schema: sensorweb2; Owner: postgres
--

COMMENT ON COLUMN rule.active_flag IS 'indicates if the rule is active (>=1) or inactive (null/0)';


--
-- TOC entry 229 (class 1259 OID 20564)
-- Name: rule_pkid_seq; Type: SEQUENCE; Schema: sensorweb2; Owner: postgres
--

CREATE SEQUENCE rule_pkid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE rule_pkid_seq OWNER TO postgres;

--
-- TOC entry 4001 (class 0 OID 0)
-- Dependencies: 229
-- Name: rule_pkid_seq; Type: SEQUENCE OWNED BY; Schema: sensorweb2; Owner: postgres
--

ALTER SEQUENCE rule_pkid_seq OWNED BY rule.pkid;


--
-- TOC entry 230 (class 1259 OID 20566)
-- Name: series; Type: TABLE; Schema: sensorweb2; Owner: postgres
--

CREATE TABLE series (
    pkid integer NOT NULL,
    category_pkid integer NOT NULL,
    phenomenon_pkid integer NOT NULL,
    procedure_pkid integer NOT NULL,
    feature_of_interest_pkid integer NOT NULL,
    decimals smallint,
    unit_pkid integer,
    first_time_stamp timestamp without time zone,
    first_numeric_value numeric(20,10),
    last_time_stamp timestamp without time zone,
    last_numeric_value numeric(20,10),
    data_origin character varying(100),
    pegel_online numeric(1,0),
    published_flag smallint DEFAULT 0,
    time_zone character varying(10),
    data_origin_comment character varying(100),
    retention_time interval
);


ALTER TABLE series OWNER TO postgres;

--
-- TOC entry 4002 (class 0 OID 0)
-- Dependencies: 230
-- Name: TABLE series; Type: COMMENT; Schema: sensorweb2; Owner: postgres
--

COMMENT ON TABLE series IS 'stores valid combinations of category, phenomenon, procedure and feature_of_interest';


--
-- TOC entry 4003 (class 0 OID 0)
-- Dependencies: 230
-- Name: COLUMN series.pkid; Type: COMMENT; Schema: sensorweb2; Owner: postgres
--

COMMENT ON COLUMN series.pkid IS 'serial primary key';


--
-- TOC entry 4004 (class 0 OID 0)
-- Dependencies: 230
-- Name: COLUMN series.category_pkid; Type: COMMENT; Schema: sensorweb2; Owner: postgres
--

COMMENT ON COLUMN series.category_pkid IS 'reference to the related category';


--
-- TOC entry 4005 (class 0 OID 0)
-- Dependencies: 230
-- Name: COLUMN series.phenomenon_pkid; Type: COMMENT; Schema: sensorweb2; Owner: postgres
--

COMMENT ON COLUMN series.phenomenon_pkid IS 'reference to the related phenomenon';


--
-- TOC entry 4006 (class 0 OID 0)
-- Dependencies: 230
-- Name: COLUMN series.procedure_pkid; Type: COMMENT; Schema: sensorweb2; Owner: postgres
--

COMMENT ON COLUMN series.procedure_pkid IS 'reference to the related procedure';


--
-- TOC entry 4007 (class 0 OID 0)
-- Dependencies: 230
-- Name: COLUMN series.feature_of_interest_pkid; Type: COMMENT; Schema: sensorweb2; Owner: postgres
--

COMMENT ON COLUMN series.feature_of_interest_pkid IS 'reference to the related feature of interest';


--
-- TOC entry 4008 (class 0 OID 0)
-- Dependencies: 230
-- Name: COLUMN series.decimals; Type: COMMENT; Schema: sensorweb2; Owner: postgres
--

COMMENT ON COLUMN series.decimals IS 'number of digits after the decimal point';


--
-- TOC entry 4009 (class 0 OID 0)
-- Dependencies: 230
-- Name: COLUMN series.unit_pkid; Type: COMMENT; Schema: sensorweb2; Owner: postgres
--

COMMENT ON COLUMN series.unit_pkid IS 'reference to the related unit';


--
-- TOC entry 4010 (class 0 OID 0)
-- Dependencies: 230
-- Name: COLUMN series.first_time_stamp; Type: COMMENT; Schema: sensorweb2; Owner: postgres
--

COMMENT ON COLUMN series.first_time_stamp IS 'point in time at which the first observation happens';


--
-- TOC entry 4011 (class 0 OID 0)
-- Dependencies: 230
-- Name: COLUMN series.first_numeric_value; Type: COMMENT; Schema: sensorweb2; Owner: postgres
--

COMMENT ON COLUMN series.first_numeric_value IS 'first observed value';


--
-- TOC entry 4012 (class 0 OID 0)
-- Dependencies: 230
-- Name: COLUMN series.last_time_stamp; Type: COMMENT; Schema: sensorweb2; Owner: postgres
--

COMMENT ON COLUMN series.last_time_stamp IS 'point in time at which the latest observation happens';


--
-- TOC entry 4013 (class 0 OID 0)
-- Dependencies: 230
-- Name: COLUMN series.last_numeric_value; Type: COMMENT; Schema: sensorweb2; Owner: postgres
--

COMMENT ON COLUMN series.last_numeric_value IS 'latest observed value';


--
-- TOC entry 4014 (class 0 OID 0)
-- Dependencies: 230
-- Name: COLUMN series.data_origin; Type: COMMENT; Schema: sensorweb2; Owner: postgres
--

COMMENT ON COLUMN series.data_origin IS 'first system storing the observed value';


--
-- TOC entry 4015 (class 0 OID 0)
-- Dependencies: 230
-- Name: COLUMN series.pegel_online; Type: COMMENT; Schema: sensorweb2; Owner: postgres
--

COMMENT ON COLUMN series.pegel_online IS 'Wird diese Zeitreihe in "Pegel Online" verwendet?';


--
-- TOC entry 4016 (class 0 OID 0)
-- Dependencies: 230
-- Name: COLUMN series.published_flag; Type: COMMENT; Schema: sensorweb2; Owner: postgres
--

COMMENT ON COLUMN series.published_flag IS 'Steuert, ob die Zeitreihe veroeffentlicht wird';


--
-- TOC entry 4017 (class 0 OID 0)
-- Dependencies: 230
-- Name: COLUMN series.time_zone; Type: COMMENT; Schema: sensorweb2; Owner: postgres
--

COMMENT ON COLUMN series.time_zone IS 'Zeitzone, z.B. "Ortszeit" oder "MESZ"';


--
-- TOC entry 4018 (class 0 OID 0)
-- Dependencies: 230
-- Name: COLUMN series.data_origin_comment; Type: COMMENT; Schema: sensorweb2; Owner: postgres
--

COMMENT ON COLUMN series.data_origin_comment IS 'Kommentar zu den Originaldaten';


--
-- TOC entry 4019 (class 0 OID 0)
-- Dependencies: 230
-- Name: COLUMN series.retention_time; Type: COMMENT; Schema: sensorweb2; Owner: postgres
--

COMMENT ON COLUMN series.retention_time IS 'Wie lange sollen die zugehoerigen Messwerte gespeichert bleiben?';


--
-- TOC entry 231 (class 1259 OID 20570)
-- Name: series_cluster; Type: TABLE; Schema: sensorweb2; Owner: postgres
--

CREATE TABLE series_cluster (
    series_pkid integer NOT NULL,
    cluster_pkid integer NOT NULL
);


ALTER TABLE series_cluster OWNER TO postgres;

--
-- TOC entry 4020 (class 0 OID 0)
-- Dependencies: 231
-- Name: TABLE series_cluster; Type: COMMENT; Schema: sensorweb2; Owner: postgres
--

COMMENT ON TABLE series_cluster IS 'clusters of series';


--
-- TOC entry 4021 (class 0 OID 0)
-- Dependencies: 231
-- Name: COLUMN series_cluster.series_pkid; Type: COMMENT; Schema: sensorweb2; Owner: postgres
--

COMMENT ON COLUMN series_cluster.series_pkid IS 'primary key of a series belonging to a cluster';


--
-- TOC entry 4022 (class 0 OID 0)
-- Dependencies: 231
-- Name: COLUMN series_cluster.cluster_pkid; Type: COMMENT; Schema: sensorweb2; Owner: postgres
--

COMMENT ON COLUMN series_cluster.cluster_pkid IS 'primary key of a cluster a series belongs to';


--
-- TOC entry 232 (class 1259 OID 20573)
-- Name: series_derived; Type: TABLE; Schema: sensorweb2; Owner: postgres
--

CREATE TABLE series_derived (
    series_pkid_base integer NOT NULL,
    series_pkid_derived integer NOT NULL,
    formula character varying(200)
);


ALTER TABLE series_derived OWNER TO postgres;

--
-- TOC entry 4023 (class 0 OID 0)
-- Dependencies: 232
-- Name: TABLE series_derived; Type: COMMENT; Schema: sensorweb2; Owner: postgres
--

COMMENT ON TABLE series_derived IS 'derived series with computed values';


--
-- TOC entry 4024 (class 0 OID 0)
-- Dependencies: 232
-- Name: COLUMN series_derived.series_pkid_base; Type: COMMENT; Schema: sensorweb2; Owner: postgres
--

COMMENT ON COLUMN series_derived.series_pkid_base IS 'primary key of the base series with the original values';


--
-- TOC entry 4025 (class 0 OID 0)
-- Dependencies: 232
-- Name: COLUMN series_derived.series_pkid_derived; Type: COMMENT; Schema: sensorweb2; Owner: postgres
--

COMMENT ON COLUMN series_derived.series_pkid_derived IS 'primary key of the derived series with the computed values';


--
-- TOC entry 4026 (class 0 OID 0)
-- Dependencies: 232
-- Name: COLUMN series_derived.formula; Type: COMMENT; Schema: sensorweb2; Owner: postgres
--

COMMENT ON COLUMN series_derived.formula IS 'calculation formula to get the computed value';


--
-- TOC entry 233 (class 1259 OID 20576)
-- Name: series_pkid_seq; Type: SEQUENCE; Schema: sensorweb2; Owner: postgres
--

CREATE SEQUENCE series_pkid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE series_pkid_seq OWNER TO postgres;

--
-- TOC entry 4027 (class 0 OID 0)
-- Dependencies: 233
-- Name: series_pkid_seq; Type: SEQUENCE OWNED BY; Schema: sensorweb2; Owner: postgres
--

ALTER SEQUENCE series_pkid_seq OWNED BY series.pkid;


--
-- TOC entry 234 (class 1259 OID 20578)
-- Name: series_pkids; Type: VIEW; Schema: sensorweb2; Owner: postgres
--

CREATE VIEW series_pkids AS
 SELECT s.pkid,
    ca.pkid AS cat_pkid,
    ca.category_id AS cat_id,
    ph.pkid AS phen_pkid,
    ph.phenomenon_id AS phen_id,
    pr.pkid AS proc_pkid,
    pr.procedure_id AS proc_id,
    foi.pkid AS foi_pkid,
    foi.feature_of_interest_id AS foi_id
   FROM ((((series s
     JOIN category ca ON ((ca.pkid = s.category_pkid)))
     JOIN phenomenon ph ON ((ph.pkid = s.phenomenon_pkid)))
     JOIN procedure pr ON ((pr.pkid = s.procedure_pkid)))
     JOIN feature_of_interest foi ON ((foi.pkid = s.feature_of_interest_pkid)))
  ORDER BY ca.pkid, ph.pkid, pr.pkid, foi.pkid;


ALTER TABLE series_pkids OWNER TO postgres;

--
-- TOC entry 4028 (class 0 OID 0)
-- Dependencies: 234
-- Name: VIEW series_pkids; Type: COMMENT; Schema: sensorweb2; Owner: postgres
--

COMMENT ON VIEW series_pkids IS 'shows all (pk-) ids used in series';


--
-- TOC entry 235 (class 1259 OID 20583)
-- Name: unit; Type: TABLE; Schema: sensorweb2; Owner: postgres
--

CREATE TABLE unit (
    pkid integer NOT NULL,
    unit character varying(30)
);


ALTER TABLE unit OWNER TO postgres;

--
-- TOC entry 4029 (class 0 OID 0)
-- Dependencies: 235
-- Name: TABLE unit; Type: COMMENT; Schema: sensorweb2; Owner: postgres
--

COMMENT ON TABLE unit IS 'represents units';


--
-- TOC entry 4030 (class 0 OID 0)
-- Dependencies: 235
-- Name: COLUMN unit.pkid; Type: COMMENT; Schema: sensorweb2; Owner: postgres
--

COMMENT ON COLUMN unit.pkid IS 'serial primary key';


--
-- TOC entry 4031 (class 0 OID 0)
-- Dependencies: 235
-- Name: COLUMN unit.unit; Type: COMMENT; Schema: sensorweb2; Owner: postgres
--

COMMENT ON COLUMN unit.unit IS 'default unit';


--
-- TOC entry 236 (class 1259 OID 20586)
-- Name: series_pkids_full; Type: VIEW; Schema: sensorweb2; Owner: postgres
--

CREATE VIEW series_pkids_full AS
 SELECT s.pkid,
    ca.pkid AS cat_pkid,
    ca.category_id AS cat_id,
    ph.pkid AS phen_pkid,
    ph.phenomenon_id AS phen_id,
    pr.pkid AS proc_pkid,
    pr.procedure_id AS proc_id,
    foi.pkid AS foi_pkid,
    foi.feature_of_interest_id AS foi_id,
    u.pkid AS unit_pkid,
    u.unit,
    s.decimals,
    s.first_time_stamp,
    s.first_numeric_value,
    s.last_time_stamp,
    s.last_numeric_value,
    s.data_origin
   FROM (((((series s
     JOIN category ca ON ((ca.pkid = s.category_pkid)))
     JOIN phenomenon ph ON ((ph.pkid = s.phenomenon_pkid)))
     JOIN procedure pr ON ((pr.pkid = s.procedure_pkid)))
     JOIN feature_of_interest foi ON ((foi.pkid = s.feature_of_interest_pkid)))
     JOIN unit u ON ((u.pkid = s.unit_pkid)))
  ORDER BY ca.pkid, ph.pkid, pr.pkid, foi.pkid;


ALTER TABLE series_pkids_full OWNER TO postgres;

--
-- TOC entry 4032 (class 0 OID 0)
-- Dependencies: 236
-- Name: VIEW series_pkids_full; Type: COMMENT; Schema: sensorweb2; Owner: postgres
--

COMMENT ON VIEW series_pkids_full IS 'shows all series (pk-) ids and their attributes';


--
-- TOC entry 237 (class 1259 OID 20591)
-- Name: series_reference; Type: TABLE; Schema: sensorweb2; Owner: postgres
--

CREATE TABLE series_reference (
    series_pkid_from integer NOT NULL,
    sort_no numeric(2,0),
    series_pkid_to integer NOT NULL
);


ALTER TABLE series_reference OWNER TO postgres;

--
-- TOC entry 4033 (class 0 OID 0)
-- Dependencies: 237
-- Name: TABLE series_reference; Type: COMMENT; Schema: sensorweb2; Owner: postgres
--

COMMENT ON TABLE series_reference IS 'valid references between series';


--
-- TOC entry 4034 (class 0 OID 0)
-- Dependencies: 237
-- Name: COLUMN series_reference.series_pkid_from; Type: COMMENT; Schema: sensorweb2; Owner: postgres
--

COMMENT ON COLUMN series_reference.series_pkid_from IS 'primary key of the series the observed values belongs to';


--
-- TOC entry 4035 (class 0 OID 0)
-- Dependencies: 237
-- Name: COLUMN series_reference.sort_no; Type: COMMENT; Schema: sensorweb2; Owner: postgres
--

COMMENT ON COLUMN series_reference.sort_no IS 'display order';


--
-- TOC entry 4036 (class 0 OID 0)
-- Dependencies: 237
-- Name: COLUMN series_reference.series_pkid_to; Type: COMMENT; Schema: sensorweb2; Owner: postgres
--

COMMENT ON COLUMN series_reference.series_pkid_to IS 'primary key of the series the comparative values belongs to';


--
-- TOC entry 238 (class 1259 OID 20594)
-- Name: subscription; Type: TABLE; Schema: sensorweb2; Owner: postgres
--

CREATE TABLE subscription (
    pkid integer NOT NULL,
    rule_pkid integer NOT NULL,
    userid bigint,
    usergroupid bigint
);


ALTER TABLE subscription OWNER TO postgres;

--
-- TOC entry 4037 (class 0 OID 0)
-- Dependencies: 238
-- Name: TABLE subscription; Type: COMMENT; Schema: sensorweb2; Owner: postgres
--

COMMENT ON TABLE subscription IS 'subscriptions of events for a user or user group';


--
-- TOC entry 4038 (class 0 OID 0)
-- Dependencies: 238
-- Name: COLUMN subscription.pkid; Type: COMMENT; Schema: sensorweb2; Owner: postgres
--

COMMENT ON COLUMN subscription.pkid IS 'serial primary key';


--
-- TOC entry 4039 (class 0 OID 0)
-- Dependencies: 238
-- Name: COLUMN subscription.rule_pkid; Type: COMMENT; Schema: sensorweb2; Owner: postgres
--

COMMENT ON COLUMN subscription.rule_pkid IS 'primary key of the rule the subscription belongs to';


--
-- TOC entry 4040 (class 0 OID 0)
-- Dependencies: 238
-- Name: COLUMN subscription.userid; Type: COMMENT; Schema: sensorweb2; Owner: postgres
--

COMMENT ON COLUMN subscription.userid IS 'primary key of the user the subscription belongs to';


--
-- TOC entry 4041 (class 0 OID 0)
-- Dependencies: 238
-- Name: COLUMN subscription.usergroupid; Type: COMMENT; Schema: sensorweb2; Owner: postgres
--

COMMENT ON COLUMN subscription.usergroupid IS 'primary key of the user group the subscription belongs to';


--
-- TOC entry 239 (class 1259 OID 20597)
-- Name: subscription_pkid_seq; Type: SEQUENCE; Schema: sensorweb2; Owner: postgres
--

CREATE SEQUENCE subscription_pkid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE subscription_pkid_seq OWNER TO postgres;

--
-- TOC entry 4042 (class 0 OID 0)
-- Dependencies: 239
-- Name: subscription_pkid_seq; Type: SEQUENCE OWNED BY; Schema: sensorweb2; Owner: postgres
--

ALTER SEQUENCE subscription_pkid_seq OWNED BY subscription.pkid;


--
-- TOC entry 240 (class 1259 OID 20599)
-- Name: trend; Type: TABLE; Schema: sensorweb2; Owner: postgres
--

CREATE TABLE trend (
    code numeric(2,0) NOT NULL,
    description character varying(100) NOT NULL
);


ALTER TABLE trend OWNER TO postgres;

--
-- TOC entry 4043 (class 0 OID 0)
-- Dependencies: 240
-- Name: TABLE trend; Type: COMMENT; Schema: sensorweb2; Owner: postgres
--

COMMENT ON TABLE trend IS 'trends of adjacent observations';


--
-- TOC entry 4044 (class 0 OID 0)
-- Dependencies: 240
-- Name: COLUMN trend.code; Type: COMMENT; Schema: sensorweb2; Owner: postgres
--

COMMENT ON COLUMN trend.code IS 'identifier: coded relation of previous and actual value (1=under, 2=equal, 3=above, 99=missing)';


--
-- TOC entry 4045 (class 0 OID 0)
-- Dependencies: 240
-- Name: COLUMN trend.description; Type: COMMENT; Schema: sensorweb2; Owner: postgres
--

COMMENT ON COLUMN trend.description IS 'default description of the relation of adjacent (previous and actual) values';


--
-- TOC entry 241 (class 1259 OID 20602)
-- Name: trend_i18n; Type: TABLE; Schema: sensorweb2; Owner: postgres
--

CREATE TABLE trend_i18n (
    pkid integer NOT NULL,
    trend_code integer NOT NULL,
    locale character varying(10) NOT NULL,
    name character varying(100),
    description character varying(100)
);


ALTER TABLE trend_i18n OWNER TO postgres;

--
-- TOC entry 4046 (class 0 OID 0)
-- Dependencies: 241
-- Name: TABLE trend_i18n; Type: COMMENT; Schema: sensorweb2; Owner: postgres
--

COMMENT ON TABLE trend_i18n IS 'internationalization of trends';


--
-- TOC entry 4047 (class 0 OID 0)
-- Dependencies: 241
-- Name: COLUMN trend_i18n.pkid; Type: COMMENT; Schema: sensorweb2; Owner: postgres
--

COMMENT ON COLUMN trend_i18n.pkid IS 'serial primary key';


--
-- TOC entry 4048 (class 0 OID 0)
-- Dependencies: 241
-- Name: COLUMN trend_i18n.trend_code; Type: COMMENT; Schema: sensorweb2; Owner: postgres
--

COMMENT ON COLUMN trend_i18n.trend_code IS 'code of the trend the record belongs to';


--
-- TOC entry 4049 (class 0 OID 0)
-- Dependencies: 241
-- Name: COLUMN trend_i18n.locale; Type: COMMENT; Schema: sensorweb2; Owner: postgres
--

COMMENT ON COLUMN trend_i18n.locale IS 'language identifier and region identifier';


--
-- TOC entry 4050 (class 0 OID 0)
-- Dependencies: 241
-- Name: COLUMN trend_i18n.name; Type: COMMENT; Schema: sensorweb2; Owner: postgres
--

COMMENT ON COLUMN trend_i18n.name IS 'name of the trend in locale''s language';


--
-- TOC entry 4051 (class 0 OID 0)
-- Dependencies: 241
-- Name: COLUMN trend_i18n.description; Type: COMMENT; Schema: sensorweb2; Owner: postgres
--

COMMENT ON COLUMN trend_i18n.description IS 'description of the trend in locale''s language';


--
-- TOC entry 242 (class 1259 OID 20605)
-- Name: trend_i18n_pkid_seq; Type: SEQUENCE; Schema: sensorweb2; Owner: postgres
--

CREATE SEQUENCE trend_i18n_pkid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE trend_i18n_pkid_seq OWNER TO postgres;

--
-- TOC entry 4052 (class 0 OID 0)
-- Dependencies: 242
-- Name: trend_i18n_pkid_seq; Type: SEQUENCE OWNED BY; Schema: sensorweb2; Owner: postgres
--

ALTER SEQUENCE trend_i18n_pkid_seq OWNED BY trend_i18n.pkid;


--
-- TOC entry 243 (class 1259 OID 20607)
-- Name: unit_i18n; Type: TABLE; Schema: sensorweb2; Owner: postgres
--

CREATE TABLE unit_i18n (
    pkid integer NOT NULL,
    unit_pkid integer NOT NULL,
    locale character varying(10) NOT NULL,
    unit character varying(30)
);


ALTER TABLE unit_i18n OWNER TO postgres;

--
-- TOC entry 4053 (class 0 OID 0)
-- Dependencies: 243
-- Name: TABLE unit_i18n; Type: COMMENT; Schema: sensorweb2; Owner: postgres
--

COMMENT ON TABLE unit_i18n IS 'internationalization of units';


--
-- TOC entry 4054 (class 0 OID 0)
-- Dependencies: 243
-- Name: COLUMN unit_i18n.pkid; Type: COMMENT; Schema: sensorweb2; Owner: postgres
--

COMMENT ON COLUMN unit_i18n.pkid IS 'serial primary key';


--
-- TOC entry 4055 (class 0 OID 0)
-- Dependencies: 243
-- Name: COLUMN unit_i18n.unit_pkid; Type: COMMENT; Schema: sensorweb2; Owner: postgres
--

COMMENT ON COLUMN unit_i18n.unit_pkid IS 'Id of the unit the record belongs to';


--
-- TOC entry 4056 (class 0 OID 0)
-- Dependencies: 243
-- Name: COLUMN unit_i18n.locale; Type: COMMENT; Schema: sensorweb2; Owner: postgres
--

COMMENT ON COLUMN unit_i18n.locale IS 'language identifier and region identifier';


--
-- TOC entry 4057 (class 0 OID 0)
-- Dependencies: 243
-- Name: COLUMN unit_i18n.unit; Type: COMMENT; Schema: sensorweb2; Owner: postgres
--

COMMENT ON COLUMN unit_i18n.unit IS 'unit in locale''s language';


--
-- TOC entry 244 (class 1259 OID 20610)
-- Name: unit_i18n_pkid_seq; Type: SEQUENCE; Schema: sensorweb2; Owner: postgres
--

CREATE SEQUENCE unit_i18n_pkid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE unit_i18n_pkid_seq OWNER TO postgres;

--
-- TOC entry 4058 (class 0 OID 0)
-- Dependencies: 244
-- Name: unit_i18n_pkid_seq; Type: SEQUENCE OWNED BY; Schema: sensorweb2; Owner: postgres
--

ALTER SEQUENCE unit_i18n_pkid_seq OWNED BY unit_i18n.pkid;


--
-- TOC entry 245 (class 1259 OID 20612)
-- Name: unit_pkid_seq; Type: SEQUENCE; Schema: sensorweb2; Owner: postgres
--

CREATE SEQUENCE unit_pkid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE unit_pkid_seq OWNER TO postgres;

--
-- TOC entry 4059 (class 0 OID 0)
-- Dependencies: 245
-- Name: unit_pkid_seq; Type: SEQUENCE OWNED BY; Schema: sensorweb2; Owner: postgres
--

ALTER SEQUENCE unit_pkid_seq OWNED BY unit.pkid;


--
-- TOC entry 246 (class 1259 OID 20614)
-- Name: user_; Type: TABLE; Schema: sensorweb2; Owner: postgres
--

CREATE TABLE user_ (
    uuid_ character varying(75),
    userid bigint NOT NULL,
    companyid bigint,
    createdate timestamp without time zone,
    modifieddate timestamp without time zone,
    defaultuser boolean,
    contactid bigint,
    password_ character varying(75),
    passwordencrypted boolean,
    passwordreset boolean,
    passwordmodifieddate timestamp without time zone,
    digest character varying(255),
    reminderqueryquestion character varying(75),
    reminderqueryanswer character varying(75),
    gracelogincount integer,
    screenname character varying(75),
    emailaddress character varying(75),
    facebookid bigint,
    openid character varying(1024),
    portraitid bigint,
    languageid character varying(75),
    timezoneid character varying(75),
    greeting character varying(255),
    comments text,
    firstname character varying(75),
    middlename character varying(75),
    lastname character varying(75),
    jobtitle character varying(100),
    logindate timestamp without time zone,
    loginip character varying(75),
    lastlogindate timestamp without time zone,
    lastloginip character varying(75),
    lastfailedlogindate timestamp without time zone,
    failedloginattempts integer,
    lockout boolean,
    lockoutdate timestamp without time zone,
    agreedtotermsofuse boolean,
    emailaddressverified boolean,
    status integer
);


ALTER TABLE user_ OWNER TO postgres;

--
-- TOC entry 4060 (class 0 OID 0)
-- Dependencies: 246
-- Name: TABLE user_; Type: COMMENT; Schema: sensorweb2; Owner: postgres
--

COMMENT ON TABLE user_ IS 'defined users, synchronized from database "fluggs"';


--
-- TOC entry 247 (class 1259 OID 20620)
-- Name: user_pkid_seq; Type: SEQUENCE; Schema: sensorweb2; Owner: postgres
--

CREATE SEQUENCE user_pkid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE user_pkid_seq OWNER TO postgres;

--
-- TOC entry 4061 (class 0 OID 0)
-- Dependencies: 247
-- Name: user_pkid_seq; Type: SEQUENCE OWNED BY; Schema: sensorweb2; Owner: postgres
--

ALTER SEQUENCE user_pkid_seq OWNED BY user_.userid;


--
-- TOC entry 248 (class 1259 OID 20623)
-- Name: usergroup; Type: TABLE; Schema: sensorweb2; Owner: postgres
--

CREATE TABLE usergroup (
    usergroupid bigint NOT NULL,
    companyid bigint,
    parentusergroupid bigint,
    name character varying(75),
    description text,
    addedbyldapimport boolean
);


ALTER TABLE usergroup OWNER TO postgres;

--
-- TOC entry 4062 (class 0 OID 0)
-- Dependencies: 248
-- Name: TABLE usergroup; Type: COMMENT; Schema: sensorweb2; Owner: postgres
--

COMMENT ON TABLE usergroup IS 'defined usergroups, synchronized from database "fluggs"';


--
-- TOC entry 249 (class 1259 OID 20629)
-- Name: usergroup_pkid_seq; Type: SEQUENCE; Schema: sensorweb2; Owner: postgres
--

CREATE SEQUENCE usergroup_pkid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE usergroup_pkid_seq OWNER TO postgres;

--
-- TOC entry 4063 (class 0 OID 0)
-- Dependencies: 249
-- Name: usergroup_pkid_seq; Type: SEQUENCE OWNED BY; Schema: sensorweb2; Owner: postgres
--

ALTER SEQUENCE usergroup_pkid_seq OWNED BY usergroup.usergroupid;


--
-- TOC entry 250 (class 1259 OID 20632)
-- Name: users_usergroups; Type: TABLE; Schema: sensorweb2; Owner: postgres
--

CREATE TABLE users_usergroups (
    userid bigint NOT NULL,
    usergroupid bigint NOT NULL
);


ALTER TABLE users_usergroups OWNER TO postgres;

--
-- TOC entry 4064 (class 0 OID 0)
-- Dependencies: 250
-- Name: TABLE users_usergroups; Type: COMMENT; Schema: sensorweb2; Owner: postgres
--

COMMENT ON TABLE users_usergroups IS 'defined links between users and usergroups, synchronized from database "fluggs"';


--
-- TOC entry 3594 (class 2604 OID 20635)
-- Name: pkid; Type: DEFAULT; Schema: sensorweb2; Owner: postgres
--

ALTER TABLE ONLY category ALTER COLUMN pkid SET DEFAULT nextval('category_pkid_seq'::regclass);


--
-- TOC entry 3595 (class 2604 OID 20636)
-- Name: pkid; Type: DEFAULT; Schema: sensorweb2; Owner: postgres
--

ALTER TABLE ONLY category_i18n ALTER COLUMN pkid SET DEFAULT nextval('category_i18n_pkid_seq'::regclass);


--
-- TOC entry 3596 (class 2604 OID 20637)
-- Name: pkid; Type: DEFAULT; Schema: sensorweb2; Owner: postgres
--

ALTER TABLE ONLY cluster ALTER COLUMN pkid SET DEFAULT nextval('cluster_pkid_seq'::regclass);


--
-- TOC entry 3597 (class 2604 OID 20638)
-- Name: pkid; Type: DEFAULT; Schema: sensorweb2; Owner: postgres
--

ALTER TABLE ONLY event ALTER COLUMN pkid SET DEFAULT nextval('event_pkid_seq'::regclass);


--
-- TOC entry 3598 (class 2604 OID 20639)
-- Name: pkid; Type: DEFAULT; Schema: sensorweb2; Owner: postgres
--

ALTER TABLE ONLY feature_of_interest ALTER COLUMN pkid SET DEFAULT nextval('feature_of_interest_pkid_seq'::regclass);


--
-- TOC entry 3599 (class 2604 OID 20640)
-- Name: pkid; Type: DEFAULT; Schema: sensorweb2; Owner: postgres
--

ALTER TABLE ONLY feature_of_interest_i18n ALTER COLUMN pkid SET DEFAULT nextval('feature_of_interest_i18n_pkid_seq'::regclass);


--
-- TOC entry 3601 (class 2604 OID 20641)
-- Name: pkid; Type: DEFAULT; Schema: sensorweb2; Owner: postgres
--

ALTER TABLE ONLY observation ALTER COLUMN pkid SET DEFAULT nextval('observation_pkid_seq'::regclass);


--
-- TOC entry 3602 (class 2604 OID 20642)
-- Name: pkid; Type: DEFAULT; Schema: sensorweb2; Owner: postgres
--

ALTER TABLE ONLY phenomenon ALTER COLUMN pkid SET DEFAULT nextval('phenomenon_pkid_seq'::regclass);


--
-- TOC entry 3603 (class 2604 OID 20643)
-- Name: pkid; Type: DEFAULT; Schema: sensorweb2; Owner: postgres
--

ALTER TABLE ONLY phenomenon_i18n ALTER COLUMN pkid SET DEFAULT nextval('phenomenon_i18n_pkid_seq'::regclass);


--
-- TOC entry 3604 (class 2604 OID 20644)
-- Name: pkid; Type: DEFAULT; Schema: sensorweb2; Owner: postgres
--

ALTER TABLE ONLY procedure ALTER COLUMN pkid SET DEFAULT nextval('procedure_pkid_seq'::regclass);


--
-- TOC entry 3605 (class 2604 OID 20645)
-- Name: pkid; Type: DEFAULT; Schema: sensorweb2; Owner: postgres
--

ALTER TABLE ONLY procedure_i18n ALTER COLUMN pkid SET DEFAULT nextval('procedure_i18n_pkid_seq'::regclass);


--
-- TOC entry 3607 (class 2604 OID 20646)
-- Name: pkid; Type: DEFAULT; Schema: sensorweb2; Owner: postgres
--

ALTER TABLE ONLY rule ALTER COLUMN pkid SET DEFAULT nextval('rule_pkid_seq'::regclass);


--
-- TOC entry 3610 (class 2604 OID 20647)
-- Name: pkid; Type: DEFAULT; Schema: sensorweb2; Owner: postgres
--

ALTER TABLE ONLY series ALTER COLUMN pkid SET DEFAULT nextval('series_pkid_seq'::regclass);


--
-- TOC entry 3612 (class 2604 OID 20648)
-- Name: pkid; Type: DEFAULT; Schema: sensorweb2; Owner: postgres
--

ALTER TABLE ONLY subscription ALTER COLUMN pkid SET DEFAULT nextval('subscription_pkid_seq'::regclass);


--
-- TOC entry 3613 (class 2604 OID 20649)
-- Name: pkid; Type: DEFAULT; Schema: sensorweb2; Owner: postgres
--

ALTER TABLE ONLY trend_i18n ALTER COLUMN pkid SET DEFAULT nextval('trend_i18n_pkid_seq'::regclass);


--
-- TOC entry 3611 (class 2604 OID 20650)
-- Name: pkid; Type: DEFAULT; Schema: sensorweb2; Owner: postgres
--

ALTER TABLE ONLY unit ALTER COLUMN pkid SET DEFAULT nextval('unit_pkid_seq'::regclass);


--
-- TOC entry 3614 (class 2604 OID 20651)
-- Name: pkid; Type: DEFAULT; Schema: sensorweb2; Owner: postgres
--

ALTER TABLE ONLY unit_i18n ALTER COLUMN pkid SET DEFAULT nextval('unit_i18n_pkid_seq'::regclass);


--
-- TOC entry 3615 (class 2604 OID 20622)
-- Name: userid; Type: DEFAULT; Schema: sensorweb2; Owner: postgres
--

ALTER TABLE ONLY user_ ALTER COLUMN userid SET DEFAULT nextval('user_pkid_seq'::regclass);


--
-- TOC entry 3616 (class 2604 OID 20631)
-- Name: usergroupid; Type: DEFAULT; Schema: sensorweb2; Owner: postgres
--

ALTER TABLE ONLY usergroup ALTER COLUMN usergroupid SET DEFAULT nextval('usergroup_pkid_seq'::regclass);


--
-- TOC entry 3866 (class 0 OID 20500)
-- Dependencies: 206
-- Data for Name: category; Type: TABLE DATA; Schema: sensorweb2; Owner: postgres
--

INSERT INTO category VALUES (4, 'test-category', NULL, NULL);


--
-- TOC entry 3867 (class 0 OID 20503)
-- Dependencies: 207
-- Data for Name: category_i18n; Type: TABLE DATA; Schema: sensorweb2; Owner: postgres
--



--
-- TOC entry 4065 (class 0 OID 0)
-- Dependencies: 208
-- Name: category_i18n_pkid_seq; Type: SEQUENCE SET; Schema: sensorweb2; Owner: postgres
--

SELECT pg_catalog.setval('category_i18n_pkid_seq', 1, false);


--
-- TOC entry 4066 (class 0 OID 0)
-- Dependencies: 209
-- Name: category_pkid_seq; Type: SEQUENCE SET; Schema: sensorweb2; Owner: postgres
--

SELECT pg_catalog.setval('category_pkid_seq', 1, false);


--
-- TOC entry 3870 (class 0 OID 20510)
-- Dependencies: 210
-- Data for Name: cluster; Type: TABLE DATA; Schema: sensorweb2; Owner: postgres
--



--
-- TOC entry 4067 (class 0 OID 0)
-- Dependencies: 211
-- Name: cluster_pkid_seq; Type: SEQUENCE SET; Schema: sensorweb2; Owner: postgres
--

SELECT pg_catalog.setval('cluster_pkid_seq', 1, false);


--
-- TOC entry 3872 (class 0 OID 20515)
-- Dependencies: 212
-- Data for Name: event; Type: TABLE DATA; Schema: sensorweb2; Owner: postgres
--

INSERT INTO event VALUES (11, 9, '2016-10-30 15:41:07.912', 62.8451703501, '2016-10-31 03:41:07.912', 61.8451703501);
INSERT INTO event VALUES (12, 9, '2016-10-31 03:41:07.912', 63.8451703501, '2016-10-31 15:41:07.912', 62.8451703501);
INSERT INTO event VALUES (13, 9, '2016-10-31 15:41:07.912', 64.8451703501, '2016-11-01 03:41:07.912', 63.8451703501);
INSERT INTO event VALUES (14, 9, '2016-11-01 03:41:07.912', 65.8451703501, '2016-11-01 15:41:07.912', 64.8451703501);
INSERT INTO event VALUES (15, 9, '2016-11-01 15:41:07.912', 66.8451703501, '2016-11-02 03:41:07.912', 65.8451703501);
INSERT INTO event VALUES (16, 9, '2016-11-02 03:41:07.912', 67.8451703501, '2016-11-02 15:41:07.912', 66.8451703501);
INSERT INTO event VALUES (17, 9, '2016-11-02 15:41:07.912', 68.8451703501, '2016-11-03 03:41:07.912', 67.8451703501);
INSERT INTO event VALUES (18, 9, '2016-11-03 03:41:07.912', 69.8451703501, '2016-11-03 15:41:07.912', 68.8451703501);
INSERT INTO event VALUES (19, 9, '2016-11-03 15:41:07.912', 70.8451703501, '2016-11-04 03:41:07.912', 69.8451703501);
INSERT INTO event VALUES (20, 9, '2016-11-04 03:41:07.912', 71.8451703501, '2016-11-04 15:41:07.912', 70.8451703501);
INSERT INTO event VALUES (21, 9, '2016-11-04 15:41:07.912', 72.8451703501, '2016-11-05 03:41:07.912', 71.8451703501);
INSERT INTO event VALUES (22, 9, '2016-11-05 03:41:07.912', 73.8451703501, '2016-11-05 15:41:07.912', 72.8451703501);
INSERT INTO event VALUES (23, 9, '2016-11-05 15:41:07.912', 74.8451703501, '2016-11-06 03:41:07.912', 73.8451703501);
INSERT INTO event VALUES (24, 9, '2016-11-06 03:41:07.912', 75.8451703501, '2016-11-06 15:41:07.912', 74.8451703501);
INSERT INTO event VALUES (25, 9, '2016-11-06 15:41:07.912', 76.8451703501, '2016-11-07 03:41:07.912', 75.8451703501);
INSERT INTO event VALUES (26, 9, '2016-11-07 03:41:07.912', 77.8451703501, '2016-11-07 15:41:07.912', 76.8451703501);
INSERT INTO event VALUES (27, 9, '2016-11-07 15:41:07.912', 78.8451703501, '2016-11-08 03:41:07.912', 77.8451703501);
INSERT INTO event VALUES (28, 9, '2016-11-08 03:41:07.912', 79.8451703501, '2016-11-08 15:41:07.912', 78.8451703501);
INSERT INTO event VALUES (29, 9, '2016-11-08 15:41:07.912', 80.8451703501, '2016-11-09 03:41:07.912', 79.8451703501);
INSERT INTO event VALUES (30, 9, '2016-11-09 03:41:07.912', 81.8451703501, '2016-11-09 15:41:07.912', 80.8451703501);
INSERT INTO event VALUES (31, 9, '2016-11-09 15:41:07.912', 82.8451703501, '2016-11-10 03:41:07.912', 81.8451703501);
INSERT INTO event VALUES (32, 9, '2016-11-10 03:41:07.912', 83.8451703501, '2016-11-10 15:41:07.912', 82.8451703501);
INSERT INTO event VALUES (33, 9, '2016-11-10 15:41:07.912', 84.8451703501, '2016-11-11 03:41:07.912', 83.8451703501);
INSERT INTO event VALUES (34, 9, '2016-11-11 03:41:07.912', 85.8451703501, '2016-11-11 15:41:07.912', 84.8451703501);
INSERT INTO event VALUES (35, 9, '2016-11-11 15:41:07.912', 86.8451703501, '2016-11-12 03:41:07.912', 85.8451703501);
INSERT INTO event VALUES (36, 9, '2016-11-12 03:41:07.912', 87.8451703501, '2016-11-12 15:41:07.912', 86.8451703501);
INSERT INTO event VALUES (37, 9, '2016-11-12 15:41:07.912', 88.8451703501, '2016-11-13 03:41:07.912', 87.8451703501);
INSERT INTO event VALUES (38, 9, '2016-11-13 03:41:07.912', 89.8451703501, '2016-11-13 15:41:07.912', 88.8451703501);
INSERT INTO event VALUES (39, 9, '2016-11-13 15:41:07.912', 90.8451703501, '2016-11-14 03:41:07.912', 89.8451703501);
INSERT INTO event VALUES (40, 9, '2016-11-14 03:41:07.912', 91.8451703501, '2016-11-14 15:41:07.912', 90.8451703501);
INSERT INTO event VALUES (41, 9, '2016-11-14 15:41:07.912', 92.8451703501, '2016-11-15 03:41:07.912', 91.8451703501);
INSERT INTO event VALUES (42, 9, '2016-11-15 03:41:07.912', 93.8451703501, '2016-11-15 15:41:07.912', 92.8451703501);
INSERT INTO event VALUES (43, 9, '2016-11-15 15:41:07.912', 94.8451703501, '2016-11-16 03:41:07.912', 93.8451703501);
INSERT INTO event VALUES (44, 9, '2016-11-16 03:41:07.912', 95.8451703501, '2016-11-16 15:41:07.912', 94.8451703501);
INSERT INTO event VALUES (45, 9, '2016-11-16 15:41:07.912', 96.8451703501, '2016-11-17 03:41:07.912', 95.8451703501);
INSERT INTO event VALUES (46, 9, '2016-11-17 03:41:07.912', 97.8451703501, '2016-11-17 15:41:07.912', 96.8451703501);
INSERT INTO event VALUES (47, 9, '2016-11-17 15:41:07.912', 98.8451703501, '2016-11-18 03:41:07.912', 97.8451703501);
INSERT INTO event VALUES (48, 9, '2016-11-18 03:41:07.912', 99.8451703501, '2016-11-18 15:41:07.912', 98.8451703501);
INSERT INTO event VALUES (49, 9, '2016-11-18 15:41:07.912', 100.8451703501, '2016-11-19 03:41:07.912', 99.8451703501);
INSERT INTO event VALUES (50, 9, '2016-11-19 03:41:07.912', 101.8451703501, '2016-11-19 15:41:07.912', 100.8451703501);
INSERT INTO event VALUES (51, 9, '2016-11-19 15:41:07.912', 102.8451703501, '2016-11-20 03:41:07.912', 101.8451703501);
INSERT INTO event VALUES (52, 9, '2016-11-20 03:41:07.912', 103.8451703501, '2016-11-20 15:41:07.912', 102.8451703501);
INSERT INTO event VALUES (53, 9, '2016-11-20 15:41:07.912', 104.8451703501, '2016-11-21 03:41:07.912', 103.8451703501);
INSERT INTO event VALUES (54, 9, '2016-11-21 03:41:07.912', 105.8451703501, '2016-11-21 15:41:07.912', 104.8451703501);
INSERT INTO event VALUES (55, 9, '2016-11-21 15:41:07.912', 106.8451703501, '2016-11-22 03:41:07.912', 105.8451703501);
INSERT INTO event VALUES (56, 9, '2016-11-22 03:41:07.912', 107.8451703501, '2016-11-22 15:41:07.912', 106.8451703501);
INSERT INTO event VALUES (57, 9, '2016-11-22 15:41:07.912', 108.8451703501, '2016-11-23 03:41:07.912', 107.8451703501);
INSERT INTO event VALUES (58, 9, '2016-11-23 03:41:07.912', 109.8451703501, '2016-11-23 15:41:07.912', 108.8451703501);
INSERT INTO event VALUES (59, 9, '2016-11-23 15:41:07.912', 110.8451703501, '2016-11-24 03:41:07.912', 109.8451703501);
INSERT INTO event VALUES (60, 9, '2016-11-24 03:41:07.912', 111.8451703501, '2016-11-24 15:41:07.912', 110.8451703501);
INSERT INTO event VALUES (61, 9, '2016-11-24 15:41:07.912', 112.8451703501, '2016-11-25 03:41:07.912', 111.8451703501);
INSERT INTO event VALUES (62, 9, '2016-11-25 03:41:07.912', 113.8451703501, '2016-11-25 15:41:07.912', 112.8451703501);
INSERT INTO event VALUES (63, 9, '2016-11-25 15:41:07.912', 114.8451703501, '2016-11-26 03:41:07.912', 113.8451703501);
INSERT INTO event VALUES (64, 9, '2016-11-26 03:41:07.912', 115.8451703501, '2016-11-26 15:41:07.912', 114.8451703501);
INSERT INTO event VALUES (65, 9, '2016-11-26 15:41:07.912', 116.8451703501, '2016-11-27 03:41:07.912', 115.8451703501);
INSERT INTO event VALUES (66, 9, '2016-11-27 03:41:07.912', 117.8451703501, '2016-11-27 15:41:07.912', 116.8451703501);
INSERT INTO event VALUES (67, 9, '2016-11-27 15:41:07.912', 118.8451703501, '2016-11-28 03:41:07.912', 117.8451703501);
INSERT INTO event VALUES (68, 9, '2016-11-28 03:41:07.912', 119.8451703501, '2016-11-28 15:41:07.912', 118.8451703501);
INSERT INTO event VALUES (69, 9, '2016-11-28 15:41:07.912', 120.8451703501, '2016-11-29 03:41:07.912', 119.8451703501);
INSERT INTO event VALUES (70, 9, '2016-11-29 03:41:07.912', 121.8451703501, '2016-11-29 15:41:07.912', 120.8451703501);
INSERT INTO event VALUES (76, 74, '2016-10-30 15:41:08.017', 173.6283813381, '2016-10-31 03:41:08.017', 172.6283813381);
INSERT INTO event VALUES (77, 74, '2016-10-31 03:41:08.017', 174.6283813381, '2016-10-31 15:41:08.017', 173.6283813381);
INSERT INTO event VALUES (78, 74, '2016-10-31 15:41:08.017', 175.6283813381, '2016-11-01 03:41:08.017', 174.6283813381);
INSERT INTO event VALUES (79, 74, '2016-11-01 03:41:08.017', 176.6283813381, '2016-11-01 15:41:08.017', 175.6283813381);
INSERT INTO event VALUES (80, 74, '2016-11-01 15:41:08.017', 177.6283813381, '2016-11-02 03:41:08.017', 176.6283813381);
INSERT INTO event VALUES (81, 74, '2016-11-02 03:41:08.017', 178.6283813381, '2016-11-02 15:41:08.017', 177.6283813381);
INSERT INTO event VALUES (82, 74, '2016-11-02 15:41:08.017', 179.6283813381, '2016-11-03 03:41:08.017', 178.6283813381);
INSERT INTO event VALUES (83, 74, '2016-11-03 03:41:08.017', 180.6283813381, '2016-11-03 15:41:08.017', 179.6283813381);
INSERT INTO event VALUES (84, 74, '2016-11-03 15:41:08.017', 181.6283813381, '2016-11-04 03:41:08.017', 180.6283813381);
INSERT INTO event VALUES (85, 74, '2016-11-04 03:41:08.017', 182.6283813381, '2016-11-04 15:41:08.017', 181.6283813381);
INSERT INTO event VALUES (86, 74, '2016-11-04 15:41:08.017', 183.6283813381, '2016-11-05 03:41:08.017', 182.6283813381);
INSERT INTO event VALUES (87, 74, '2016-11-05 03:41:08.017', 184.6283813381, '2016-11-05 15:41:08.017', 183.6283813381);
INSERT INTO event VALUES (88, 74, '2016-11-05 15:41:08.017', 185.6283813381, '2016-11-06 03:41:08.017', 184.6283813381);
INSERT INTO event VALUES (89, 74, '2016-11-06 03:41:08.017', 186.6283813381, '2016-11-06 15:41:08.017', 185.6283813381);
INSERT INTO event VALUES (90, 74, '2016-11-06 15:41:08.017', 187.6283813381, '2016-11-07 03:41:08.017', 186.6283813381);
INSERT INTO event VALUES (91, 74, '2016-11-07 03:41:08.017', 188.6283813381, '2016-11-07 15:41:08.017', 187.6283813381);
INSERT INTO event VALUES (92, 74, '2016-11-07 15:41:08.017', 189.6283813381, '2016-11-08 03:41:08.017', 188.6283813381);
INSERT INTO event VALUES (93, 74, '2016-11-08 03:41:08.017', 190.6283813381, '2016-11-08 15:41:08.017', 189.6283813381);
INSERT INTO event VALUES (94, 74, '2016-11-08 15:41:08.017', 191.6283813381, '2016-11-09 03:41:08.017', 190.6283813381);
INSERT INTO event VALUES (95, 74, '2016-11-09 03:41:08.017', 192.6283813381, '2016-11-09 15:41:08.017', 191.6283813381);
INSERT INTO event VALUES (96, 74, '2016-11-09 15:41:08.017', 193.6283813381, '2016-11-10 03:41:08.017', 192.6283813381);
INSERT INTO event VALUES (97, 74, '2016-11-10 03:41:08.017', 194.6283813381, '2016-11-10 15:41:08.017', 193.6283813381);
INSERT INTO event VALUES (98, 74, '2016-11-10 15:41:08.017', 195.6283813381, '2016-11-11 03:41:08.017', 194.6283813381);
INSERT INTO event VALUES (99, 74, '2016-11-11 03:41:08.017', 196.6283813381, '2016-11-11 15:41:08.017', 195.6283813381);
INSERT INTO event VALUES (100, 74, '2016-11-11 15:41:08.017', 197.6283813381, '2016-11-12 03:41:08.017', 196.6283813381);
INSERT INTO event VALUES (101, 74, '2016-11-12 03:41:08.017', 198.6283813381, '2016-11-12 15:41:08.017', 197.6283813381);
INSERT INTO event VALUES (102, 74, '2016-11-12 15:41:08.017', 199.6283813381, '2016-11-13 03:41:08.017', 198.6283813381);
INSERT INTO event VALUES (103, 74, '2016-11-13 03:41:08.017', 200.6283813381, '2016-11-13 15:41:08.017', 199.6283813381);
INSERT INTO event VALUES (104, 74, '2016-11-13 15:41:08.017', 201.6283813381, '2016-11-14 03:41:08.017', 200.6283813381);
INSERT INTO event VALUES (105, 74, '2016-11-14 03:41:08.017', 202.6283813381, '2016-11-14 15:41:08.017', 201.6283813381);
INSERT INTO event VALUES (106, 74, '2016-11-14 15:41:08.017', 203.6283813381, '2016-11-15 03:41:08.017', 202.6283813381);
INSERT INTO event VALUES (107, 74, '2016-11-15 03:41:08.017', 204.6283813381, '2016-11-15 15:41:08.017', 203.6283813381);
INSERT INTO event VALUES (108, 74, '2016-11-15 15:41:08.017', 205.6283813381, '2016-11-16 03:41:08.017', 204.6283813381);
INSERT INTO event VALUES (109, 74, '2016-11-16 03:41:08.017', 206.6283813381, '2016-11-16 15:41:08.017', 205.6283813381);
INSERT INTO event VALUES (110, 74, '2016-11-16 15:41:08.017', 207.6283813381, '2016-11-17 03:41:08.017', 206.6283813381);
INSERT INTO event VALUES (111, 74, '2016-11-17 03:41:08.017', 208.6283813381, '2016-11-17 15:41:08.017', 207.6283813381);
INSERT INTO event VALUES (112, 74, '2016-11-17 15:41:08.017', 209.6283813381, '2016-11-18 03:41:08.017', 208.6283813381);
INSERT INTO event VALUES (113, 74, '2016-11-18 03:41:08.017', 210.6283813381, '2016-11-18 15:41:08.017', 209.6283813381);
INSERT INTO event VALUES (114, 74, '2016-11-18 15:41:08.017', 211.6283813381, '2016-11-19 03:41:08.017', 210.6283813381);
INSERT INTO event VALUES (115, 74, '2016-11-19 03:41:08.017', 212.6283813381, '2016-11-19 15:41:08.017', 211.6283813381);
INSERT INTO event VALUES (116, 74, '2016-11-19 15:41:08.017', 213.6283813381, '2016-11-20 03:41:08.017', 212.6283813381);
INSERT INTO event VALUES (117, 74, '2016-11-20 03:41:08.017', 214.6283813381, '2016-11-20 15:41:08.017', 213.6283813381);
INSERT INTO event VALUES (118, 74, '2016-11-20 15:41:08.017', 215.6283813381, '2016-11-21 03:41:08.017', 214.6283813381);
INSERT INTO event VALUES (119, 74, '2016-11-21 03:41:08.017', 216.6283813381, '2016-11-21 15:41:08.017', 215.6283813381);
INSERT INTO event VALUES (120, 74, '2016-11-21 15:41:08.017', 217.6283813381, '2016-11-22 03:41:08.017', 216.6283813381);
INSERT INTO event VALUES (121, 74, '2016-11-22 03:41:08.017', 218.6283813381, '2016-11-22 15:41:08.017', 217.6283813381);
INSERT INTO event VALUES (122, 74, '2016-11-22 15:41:08.017', 219.6283813381, '2016-11-23 03:41:08.017', 218.6283813381);
INSERT INTO event VALUES (123, 74, '2016-11-23 03:41:08.017', 220.6283813381, '2016-11-23 15:41:08.017', 219.6283813381);
INSERT INTO event VALUES (124, 74, '2016-11-23 15:41:08.017', 221.6283813381, '2016-11-24 03:41:08.017', 220.6283813381);
INSERT INTO event VALUES (125, 74, '2016-11-24 03:41:08.017', 222.6283813381, '2016-11-24 15:41:08.017', 221.6283813381);
INSERT INTO event VALUES (126, 74, '2016-11-24 15:41:08.017', 223.6283813381, '2016-11-25 03:41:08.017', 222.6283813381);
INSERT INTO event VALUES (127, 74, '2016-11-25 03:41:08.017', 224.6283813381, '2016-11-25 15:41:08.017', 223.6283813381);
INSERT INTO event VALUES (128, 74, '2016-11-25 15:41:08.017', 225.6283813381, '2016-11-26 03:41:08.017', 224.6283813381);
INSERT INTO event VALUES (129, 74, '2016-11-26 03:41:08.017', 226.6283813381, '2016-11-26 15:41:08.017', 225.6283813381);
INSERT INTO event VALUES (130, 74, '2016-11-26 15:41:08.017', 227.6283813381, '2016-11-27 03:41:08.017', 226.6283813381);
INSERT INTO event VALUES (131, 74, '2016-11-27 03:41:08.017', 228.6283813381, '2016-11-27 15:41:08.017', 227.6283813381);
INSERT INTO event VALUES (132, 74, '2016-11-27 15:41:08.017', 229.6283813381, '2016-11-28 03:41:08.017', 228.6283813381);
INSERT INTO event VALUES (133, 74, '2016-11-28 03:41:08.017', 230.6283813381, '2016-11-28 15:41:08.017', 229.6283813381);
INSERT INTO event VALUES (134, 74, '2016-11-28 15:41:08.017', 231.6283813381, '2016-11-29 03:41:08.017', 230.6283813381);
INSERT INTO event VALUES (135, 74, '2016-11-29 03:41:08.017', 232.6283813381, '2016-11-29 15:41:08.017', 231.6283813381);


--
-- TOC entry 4068 (class 0 OID 0)
-- Dependencies: 213
-- Name: event_pkid_seq; Type: SEQUENCE SET; Schema: sensorweb2; Owner: postgres
--

SELECT pg_catalog.setval('event_pkid_seq', 1, false);


--
-- TOC entry 3874 (class 0 OID 20520)
-- Dependencies: 214
-- Data for Name: feature_of_interest; Type: TABLE DATA; Schema: sensorweb2; Owner: postgres
--

INSERT INTO feature_of_interest VALUES (7, 'test-feature-28690f', 'Test Feature', NULL, 'point', 71349, 'its not a bug');
INSERT INTO feature_of_interest VALUES (72, 'test-feature-8b1676', 'Test Feature', NULL, 'point', 16031, 'its not a bug');


--
-- TOC entry 3875 (class 0 OID 20526)
-- Dependencies: 215
-- Data for Name: feature_of_interest_i18n; Type: TABLE DATA; Schema: sensorweb2; Owner: postgres
--



--
-- TOC entry 4069 (class 0 OID 0)
-- Dependencies: 216
-- Name: feature_of_interest_i18n_pkid_seq; Type: SEQUENCE SET; Schema: sensorweb2; Owner: postgres
--

SELECT pg_catalog.setval('feature_of_interest_i18n_pkid_seq', 1, false);


--
-- TOC entry 4070 (class 0 OID 0)
-- Dependencies: 217
-- Name: feature_of_interest_pkid_seq; Type: SEQUENCE SET; Schema: sensorweb2; Owner: postgres
--

SELECT pg_catalog.setval('feature_of_interest_pkid_seq', 1, false);


--
-- TOC entry 4071 (class 0 OID 0)
-- Dependencies: 251
-- Name: hibernate_sequence; Type: SEQUENCE SET; Schema: sensorweb2; Owner: postgres
--

SELECT pg_catalog.setval('hibernate_sequence', 135, true);


--
-- TOC entry 3878 (class 0 OID 20533)
-- Dependencies: 218
-- Data for Name: observation; Type: TABLE DATA; Schema: sensorweb2; Owner: postgres
--



--
-- TOC entry 4072 (class 0 OID 0)
-- Dependencies: 219
-- Name: observation_pkid_seq; Type: SEQUENCE SET; Schema: sensorweb2; Owner: postgres
--

SELECT pg_catalog.setval('observation_pkid_seq', 1, false);


--
-- TOC entry 3880 (class 0 OID 20539)
-- Dependencies: 220
-- Data for Name: phenomenon; Type: TABLE DATA; Schema: sensorweb2; Owner: postgres
--

INSERT INTO phenomenon VALUES (5, 'test-phenomenon', NULL, NULL);


--
-- TOC entry 3881 (class 0 OID 20542)
-- Dependencies: 221
-- Data for Name: phenomenon_i18n; Type: TABLE DATA; Schema: sensorweb2; Owner: postgres
--



--
-- TOC entry 4073 (class 0 OID 0)
-- Dependencies: 222
-- Name: phenomenon_i18n_pkid_seq; Type: SEQUENCE SET; Schema: sensorweb2; Owner: postgres
--

SELECT pg_catalog.setval('phenomenon_i18n_pkid_seq', 1, false);


--
-- TOC entry 4074 (class 0 OID 0)
-- Dependencies: 223
-- Name: phenomenon_pkid_seq; Type: SEQUENCE SET; Schema: sensorweb2; Owner: postgres
--

SELECT pg_catalog.setval('phenomenon_pkid_seq', 1, false);


--
-- TOC entry 3884 (class 0 OID 20549)
-- Dependencies: 224
-- Data for Name: procedure; Type: TABLE DATA; Schema: sensorweb2; Owner: postgres
--

INSERT INTO procedure VALUES (6, 'test-procedure', NULL, NULL, NULL, NULL);


--
-- TOC entry 3885 (class 0 OID 20552)
-- Dependencies: 225
-- Data for Name: procedure_i18n; Type: TABLE DATA; Schema: sensorweb2; Owner: postgres
--



--
-- TOC entry 4075 (class 0 OID 0)
-- Dependencies: 226
-- Name: procedure_i18n_pkid_seq; Type: SEQUENCE SET; Schema: sensorweb2; Owner: postgres
--

SELECT pg_catalog.setval('procedure_i18n_pkid_seq', 1, false);


--
-- TOC entry 4076 (class 0 OID 0)
-- Dependencies: 227
-- Name: procedure_pkid_seq; Type: SEQUENCE SET; Schema: sensorweb2; Owner: postgres
--

SELECT pg_catalog.setval('procedure_pkid_seq', 1, false);


--
-- TOC entry 3888 (class 0 OID 20559)
-- Dependencies: 228
-- Data for Name: rule; Type: TABLE DATA; Schema: sensorweb2; Owner: postgres
--

INSERT INTO rule VALUES (9, 8, 22.0000000000, 11, 1);
INSERT INTO rule VALUES (74, 73, 22.0000000000, 11, 1);


--
-- TOC entry 4077 (class 0 OID 0)
-- Dependencies: 229
-- Name: rule_pkid_seq; Type: SEQUENCE SET; Schema: sensorweb2; Owner: postgres
--

SELECT pg_catalog.setval('rule_pkid_seq', 1, false);


--
-- TOC entry 3890 (class 0 OID 20566)
-- Dependencies: 230
-- Data for Name: series; Type: TABLE DATA; Schema: sensorweb2; Owner: postgres
--

INSERT INTO series VALUES (8, 4, 5, 6, 7, NULL, 3, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL);
INSERT INTO series VALUES (73, 4, 5, 6, 72, NULL, 71, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL);


--
-- TOC entry 3891 (class 0 OID 20570)
-- Dependencies: 231
-- Data for Name: series_cluster; Type: TABLE DATA; Schema: sensorweb2; Owner: postgres
--



--
-- TOC entry 3892 (class 0 OID 20573)
-- Dependencies: 232
-- Data for Name: series_derived; Type: TABLE DATA; Schema: sensorweb2; Owner: postgres
--



--
-- TOC entry 4078 (class 0 OID 0)
-- Dependencies: 233
-- Name: series_pkid_seq; Type: SEQUENCE SET; Schema: sensorweb2; Owner: postgres
--

SELECT pg_catalog.setval('series_pkid_seq', 1, false);


--
-- TOC entry 3895 (class 0 OID 20591)
-- Dependencies: 237
-- Data for Name: series_reference; Type: TABLE DATA; Schema: sensorweb2; Owner: postgres
--



--
-- TOC entry 3896 (class 0 OID 20594)
-- Dependencies: 238
-- Data for Name: subscription; Type: TABLE DATA; Schema: sensorweb2; Owner: postgres
--

INSERT INTO subscription VALUES (10, 9, NULL, NULL);
INSERT INTO subscription VALUES (75, 74, NULL, NULL);


--
-- TOC entry 4079 (class 0 OID 0)
-- Dependencies: 239
-- Name: subscription_pkid_seq; Type: SEQUENCE SET; Schema: sensorweb2; Owner: postgres
--

SELECT pg_catalog.setval('subscription_pkid_seq', 1, false);


--
-- TOC entry 3898 (class 0 OID 20599)
-- Dependencies: 240
-- Data for Name: trend; Type: TABLE DATA; Schema: sensorweb2; Owner: postgres
--

INSERT INTO trend VALUES (11, 'vorheriger Wert: kleiner als Grenzwert, aktueller Wert: kleiner als Grenzwert');
INSERT INTO trend VALUES (12, 'vorheriger Wert: kleiner als Grenzwert, aktueller Wert: gleich Grenzwert');
INSERT INTO trend VALUES (13, 'vorheriger Wert: kleiner als Grenzwert, aktueller Wert: groesser als Grenzwert');
INSERT INTO trend VALUES (21, 'vorheriger Wert: gleich Grenzwert, aktueller Wert: kleiner als Grenzwert');
INSERT INTO trend VALUES (22, 'vorheriger Wert: gleich Grenzwert, aktueller Wert: gleich Grenzwert');
INSERT INTO trend VALUES (23, 'vorheriger Wert: gleich Grenzwert, aktueller Wert: groesser als Grenzwert');
INSERT INTO trend VALUES (31, 'vorheriger Wert: groesser als Grenzwert, aktueller Wert: kleiner als Grenzwert');
INSERT INTO trend VALUES (32, 'vorheriger Wert: groesser als Grenzwert, aktueller Wert: gleich Grenzwert');
INSERT INTO trend VALUES (33, 'vorheriger Wert: groesser als Grenzwert, aktueller Wert: groesser als Grenzwert');
INSERT INTO trend VALUES (99, 'Ausfall');


--
-- TOC entry 3899 (class 0 OID 20602)
-- Dependencies: 241
-- Data for Name: trend_i18n; Type: TABLE DATA; Schema: sensorweb2; Owner: postgres
--

INSERT INTO trend_i18n VALUES (1, 11, 'en', 'previous value: less than threshold, actual value: less than threshold', NULL);
INSERT INTO trend_i18n VALUES (2, 12, 'en', 'previous value: less than threshold, actual value: equal to threshold', NULL);
INSERT INTO trend_i18n VALUES (3, 13, 'en', 'previous value: less than threshold, actual value: more than threshold', NULL);
INSERT INTO trend_i18n VALUES (4, 21, 'en', 'previous value: equal to threshold, actual value: less than threshold', NULL);
INSERT INTO trend_i18n VALUES (5, 22, 'en', 'previous value: equal to threshold, actual value: equal to threshold', NULL);
INSERT INTO trend_i18n VALUES (6, 23, 'en', 'previous value: equal to threshold, actual value: more than threshold', NULL);
INSERT INTO trend_i18n VALUES (7, 31, 'en', 'previous value: more than threshold, actual value: less than threshold', NULL);
INSERT INTO trend_i18n VALUES (8, 32, 'en', 'previous value: more than threshold, actual value: equal to threshold', NULL);
INSERT INTO trend_i18n VALUES (9, 33, 'en', 'previous value: more than threshold, actual value: more than threshold', NULL);
INSERT INTO trend_i18n VALUES (10, 99, 'en', 'outage', NULL);


--
-- TOC entry 4080 (class 0 OID 0)
-- Dependencies: 242
-- Name: trend_i18n_pkid_seq; Type: SEQUENCE SET; Schema: sensorweb2; Owner: postgres
--

SELECT pg_catalog.setval('trend_i18n_pkid_seq', 1, false);


--
-- TOC entry 3894 (class 0 OID 20583)
-- Dependencies: 235
-- Data for Name: unit; Type: TABLE DATA; Schema: sensorweb2; Owner: postgres
--

INSERT INTO unit VALUES (3, 'cm');
INSERT INTO unit VALUES (71, 'cm');


--
-- TOC entry 3901 (class 0 OID 20607)
-- Dependencies: 243
-- Data for Name: unit_i18n; Type: TABLE DATA; Schema: sensorweb2; Owner: postgres
--



--
-- TOC entry 4081 (class 0 OID 0)
-- Dependencies: 244
-- Name: unit_i18n_pkid_seq; Type: SEQUENCE SET; Schema: sensorweb2; Owner: postgres
--

SELECT pg_catalog.setval('unit_i18n_pkid_seq', 1, false);


--
-- TOC entry 4082 (class 0 OID 0)
-- Dependencies: 245
-- Name: unit_pkid_seq; Type: SEQUENCE SET; Schema: sensorweb2; Owner: postgres
--

SELECT pg_catalog.setval('unit_pkid_seq', 1, false);


--
-- TOC entry 3904 (class 0 OID 20614)
-- Dependencies: 246
-- Data for Name: user_; Type: TABLE DATA; Schema: sensorweb2; Owner: postgres
--

INSERT INTO user_ VALUES ('matthes', 2, NULL, NULL, NULL, NULL, NULL, '$2a$10$5m48v.MakzXStoeB1jf5Wu3bHruneN7so6s5ufth8e5vQTs0nG4ja', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'm.rieke@52north.org', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'm', NULL, 'r', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1);


--
-- TOC entry 4083 (class 0 OID 0)
-- Dependencies: 247
-- Name: user_pkid_seq; Type: SEQUENCE SET; Schema: sensorweb2; Owner: postgres
--

SELECT pg_catalog.setval('user_pkid_seq', 1, false);


--
-- TOC entry 3906 (class 0 OID 20623)
-- Dependencies: 248
-- Data for Name: usergroup; Type: TABLE DATA; Schema: sensorweb2; Owner: postgres
--

INSERT INTO usergroup VALUES (1, NULL, NULL, 'admins', 'admin group', true);


--
-- TOC entry 4084 (class 0 OID 0)
-- Dependencies: 249
-- Name: usergroup_pkid_seq; Type: SEQUENCE SET; Schema: sensorweb2; Owner: postgres
--

SELECT pg_catalog.setval('usergroup_pkid_seq', 1, false);


--
-- TOC entry 3908 (class 0 OID 20632)
-- Dependencies: 250
-- Data for Name: users_usergroups; Type: TABLE DATA; Schema: sensorweb2; Owner: postgres
--

INSERT INTO users_usergroups VALUES (2, 1);


--
-- TOC entry 3618 (class 2606 OID 20653)
-- Name: category_category_id_key; Type: CONSTRAINT; Schema: sensorweb2; Owner: postgres
--

ALTER TABLE ONLY category
    ADD CONSTRAINT category_category_id_key UNIQUE (category_id);


--
-- TOC entry 3622 (class 2606 OID 20655)
-- Name: category_i18n_category_pkid_key; Type: CONSTRAINT; Schema: sensorweb2; Owner: postgres
--

ALTER TABLE ONLY category_i18n
    ADD CONSTRAINT category_i18n_category_pkid_key UNIQUE (category_pkid, locale);


--
-- TOC entry 3624 (class 2606 OID 20657)
-- Name: category_i18n_pkey; Type: CONSTRAINT; Schema: sensorweb2; Owner: postgres
--

ALTER TABLE ONLY category_i18n
    ADD CONSTRAINT category_i18n_pkey PRIMARY KEY (pkid);


--
-- TOC entry 3620 (class 2606 OID 20659)
-- Name: category_pkey; Type: CONSTRAINT; Schema: sensorweb2; Owner: postgres
--

ALTER TABLE ONLY category
    ADD CONSTRAINT category_pkey PRIMARY KEY (pkid);


--
-- TOC entry 3626 (class 2606 OID 20661)
-- Name: cluster_cluster_id_key; Type: CONSTRAINT; Schema: sensorweb2; Owner: postgres
--

ALTER TABLE ONLY cluster
    ADD CONSTRAINT cluster_cluster_id_key UNIQUE (cluster_id);


--
-- TOC entry 3628 (class 2606 OID 20663)
-- Name: cluster_pkey; Type: CONSTRAINT; Schema: sensorweb2; Owner: postgres
--

ALTER TABLE ONLY cluster
    ADD CONSTRAINT cluster_pkey PRIMARY KEY (pkid);


--
-- TOC entry 3630 (class 2606 OID 20665)
-- Name: event_pkey; Type: CONSTRAINT; Schema: sensorweb2; Owner: postgres
--

ALTER TABLE ONLY event
    ADD CONSTRAINT event_pkey PRIMARY KEY (pkid);


--
-- TOC entry 3632 (class 2606 OID 20667)
-- Name: event_unique; Type: CONSTRAINT; Schema: sensorweb2; Owner: postgres
--

ALTER TABLE ONLY event
    ADD CONSTRAINT event_unique UNIQUE (rule_pkid, time_stamp, numeric_value);


--
-- TOC entry 3634 (class 2606 OID 20669)
-- Name: feature_of_interest_feature_of_interest_id_key; Type: CONSTRAINT; Schema: sensorweb2; Owner: postgres
--

ALTER TABLE ONLY feature_of_interest
    ADD CONSTRAINT feature_of_interest_feature_of_interest_id_key UNIQUE (feature_of_interest_id);


--
-- TOC entry 3640 (class 2606 OID 20671)
-- Name: feature_of_interest_i18n_feature_of_interest_pkid_key; Type: CONSTRAINT; Schema: sensorweb2; Owner: postgres
--

ALTER TABLE ONLY feature_of_interest_i18n
    ADD CONSTRAINT feature_of_interest_i18n_feature_of_interest_pkid_key UNIQUE (feature_of_interest_pkid, locale);


--
-- TOC entry 3642 (class 2606 OID 20673)
-- Name: feature_of_interest_i18n_pkey; Type: CONSTRAINT; Schema: sensorweb2; Owner: postgres
--

ALTER TABLE ONLY feature_of_interest_i18n
    ADD CONSTRAINT feature_of_interest_i18n_pkey PRIMARY KEY (pkid);


--
-- TOC entry 3636 (class 2606 OID 20675)
-- Name: feature_of_interest_pkey; Type: CONSTRAINT; Schema: sensorweb2; Owner: postgres
--

ALTER TABLE ONLY feature_of_interest
    ADD CONSTRAINT feature_of_interest_pkey PRIMARY KEY (pkid);


--
-- TOC entry 3638 (class 2606 OID 20677)
-- Name: feature_of_interest_reference_wv_id_key; Type: CONSTRAINT; Schema: sensorweb2; Owner: postgres
--

ALTER TABLE ONLY feature_of_interest
    ADD CONSTRAINT feature_of_interest_reference_wv_id_key UNIQUE (reference_wv_id);


--
-- TOC entry 3646 (class 2606 OID 20679)
-- Name: observation_pkey; Type: CONSTRAINT; Schema: sensorweb2; Owner: postgres
--

ALTER TABLE ONLY observation
    ADD CONSTRAINT observation_pkey PRIMARY KEY (pkid);


--
-- TOC entry 3652 (class 2606 OID 20681)
-- Name: phenomenon_i18n_phenomenon_pkid_key; Type: CONSTRAINT; Schema: sensorweb2; Owner: postgres
--

ALTER TABLE ONLY phenomenon_i18n
    ADD CONSTRAINT phenomenon_i18n_phenomenon_pkid_key UNIQUE (phenomenon_pkid, locale);


--
-- TOC entry 3654 (class 2606 OID 20683)
-- Name: phenomenon_i18n_pkey; Type: CONSTRAINT; Schema: sensorweb2; Owner: postgres
--

ALTER TABLE ONLY phenomenon_i18n
    ADD CONSTRAINT phenomenon_i18n_pkey PRIMARY KEY (pkid);


--
-- TOC entry 3648 (class 2606 OID 20685)
-- Name: phenomenon_phenomenon_id_key; Type: CONSTRAINT; Schema: sensorweb2; Owner: postgres
--

ALTER TABLE ONLY phenomenon
    ADD CONSTRAINT phenomenon_phenomenon_id_key UNIQUE (phenomenon_id);


--
-- TOC entry 3650 (class 2606 OID 20687)
-- Name: phenomenon_pkey; Type: CONSTRAINT; Schema: sensorweb2; Owner: postgres
--

ALTER TABLE ONLY phenomenon
    ADD CONSTRAINT phenomenon_pkey PRIMARY KEY (pkid);


--
-- TOC entry 3660 (class 2606 OID 20689)
-- Name: procedure_i18n_pkey; Type: CONSTRAINT; Schema: sensorweb2; Owner: postgres
--

ALTER TABLE ONLY procedure_i18n
    ADD CONSTRAINT procedure_i18n_pkey PRIMARY KEY (pkid);


--
-- TOC entry 3662 (class 2606 OID 20691)
-- Name: procedure_i18n_procedure_pkid_key; Type: CONSTRAINT; Schema: sensorweb2; Owner: postgres
--

ALTER TABLE ONLY procedure_i18n
    ADD CONSTRAINT procedure_i18n_procedure_pkid_key UNIQUE (procedure_pkid, locale);


--
-- TOC entry 3656 (class 2606 OID 20693)
-- Name: procedure_pkey; Type: CONSTRAINT; Schema: sensorweb2; Owner: postgres
--

ALTER TABLE ONLY procedure
    ADD CONSTRAINT procedure_pkey PRIMARY KEY (pkid);


--
-- TOC entry 3658 (class 2606 OID 20695)
-- Name: procedure_procedure_id_key; Type: CONSTRAINT; Schema: sensorweb2; Owner: postgres
--

ALTER TABLE ONLY procedure
    ADD CONSTRAINT procedure_procedure_id_key UNIQUE (procedure_id);


--
-- TOC entry 3664 (class 2606 OID 20697)
-- Name: rule_pkey; Type: CONSTRAINT; Schema: sensorweb2; Owner: postgres
--

ALTER TABLE ONLY rule
    ADD CONSTRAINT rule_pkey PRIMARY KEY (pkid);


--
-- TOC entry 3666 (class 2606 OID 20699)
-- Name: rule_unique; Type: CONSTRAINT; Schema: sensorweb2; Owner: postgres
--

ALTER TABLE ONLY rule
    ADD CONSTRAINT rule_unique UNIQUE (series_pkid, threshold, trend_code);


--
-- TOC entry 3668 (class 2606 OID 20701)
-- Name: series_category_pkid_key; Type: CONSTRAINT; Schema: sensorweb2; Owner: postgres
--

ALTER TABLE ONLY series
    ADD CONSTRAINT series_category_pkid_key UNIQUE (category_pkid, phenomenon_pkid, procedure_pkid, feature_of_interest_pkid);


--
-- TOC entry 3672 (class 2606 OID 20703)
-- Name: series_cluster_pkey; Type: CONSTRAINT; Schema: sensorweb2; Owner: postgres
--

ALTER TABLE ONLY series_cluster
    ADD CONSTRAINT series_cluster_pkey PRIMARY KEY (series_pkid, cluster_pkid);


--
-- TOC entry 3674 (class 2606 OID 20705)
-- Name: series_derived_pkey; Type: CONSTRAINT; Schema: sensorweb2; Owner: postgres
--

ALTER TABLE ONLY series_derived
    ADD CONSTRAINT series_derived_pkey PRIMARY KEY (series_pkid_base, series_pkid_derived);


--
-- TOC entry 3670 (class 2606 OID 20707)
-- Name: series_pkey; Type: CONSTRAINT; Schema: sensorweb2; Owner: postgres
--

ALTER TABLE ONLY series
    ADD CONSTRAINT series_pkey PRIMARY KEY (pkid);


--
-- TOC entry 3678 (class 2606 OID 20709)
-- Name: series_reference_pkey; Type: CONSTRAINT; Schema: sensorweb2; Owner: postgres
--

ALTER TABLE ONLY series_reference
    ADD CONSTRAINT series_reference_pkey PRIMARY KEY (series_pkid_from, series_pkid_to);


--
-- TOC entry 3680 (class 2606 OID 20711)
-- Name: subscription_pkey; Type: CONSTRAINT; Schema: sensorweb2; Owner: postgres
--

ALTER TABLE ONLY subscription
    ADD CONSTRAINT subscription_pkey PRIMARY KEY (pkid);


--
-- TOC entry 3682 (class 2606 OID 20713)
-- Name: subscription_unique_user; Type: CONSTRAINT; Schema: sensorweb2; Owner: postgres
--

ALTER TABLE ONLY subscription
    ADD CONSTRAINT subscription_unique_user UNIQUE (rule_pkid, userid);


--
-- TOC entry 3684 (class 2606 OID 20715)
-- Name: subscription_unique_usergroupid; Type: CONSTRAINT; Schema: sensorweb2; Owner: postgres
--

ALTER TABLE ONLY subscription
    ADD CONSTRAINT subscription_unique_usergroupid UNIQUE (rule_pkid, usergroupid);


--
-- TOC entry 3686 (class 2606 OID 20717)
-- Name: trend_code_pkey; Type: CONSTRAINT; Schema: sensorweb2; Owner: postgres
--

ALTER TABLE ONLY trend
    ADD CONSTRAINT trend_code_pkey PRIMARY KEY (code);


--
-- TOC entry 3688 (class 2606 OID 20719)
-- Name: trend_i18n_pkey; Type: CONSTRAINT; Schema: sensorweb2; Owner: postgres
--

ALTER TABLE ONLY trend_i18n
    ADD CONSTRAINT trend_i18n_pkey PRIMARY KEY (pkid);


--
-- TOC entry 3690 (class 2606 OID 20721)
-- Name: trend_i18n_unique; Type: CONSTRAINT; Schema: sensorweb2; Owner: postgres
--

ALTER TABLE ONLY trend_i18n
    ADD CONSTRAINT trend_i18n_unique UNIQUE (trend_code, locale);


--
-- TOC entry 3692 (class 2606 OID 20723)
-- Name: unit_i18n_pkey; Type: CONSTRAINT; Schema: sensorweb2; Owner: postgres
--

ALTER TABLE ONLY unit_i18n
    ADD CONSTRAINT unit_i18n_pkey PRIMARY KEY (pkid);


--
-- TOC entry 3694 (class 2606 OID 20725)
-- Name: unit_i18n_unit_pkid_key; Type: CONSTRAINT; Schema: sensorweb2; Owner: postgres
--

ALTER TABLE ONLY unit_i18n
    ADD CONSTRAINT unit_i18n_unit_pkid_key UNIQUE (unit_pkid, locale);


--
-- TOC entry 3676 (class 2606 OID 20727)
-- Name: unit_pkey; Type: CONSTRAINT; Schema: sensorweb2; Owner: postgres
--

ALTER TABLE ONLY unit
    ADD CONSTRAINT unit_pkey PRIMARY KEY (pkid);


--
-- TOC entry 3696 (class 2606 OID 20729)
-- Name: user__pkey; Type: CONSTRAINT; Schema: sensorweb2; Owner: postgres
--

ALTER TABLE ONLY user_
    ADD CONSTRAINT user__pkey PRIMARY KEY (userid);


--
-- TOC entry 3698 (class 2606 OID 20731)
-- Name: usergroup_pkey; Type: CONSTRAINT; Schema: sensorweb2; Owner: postgres
--

ALTER TABLE ONLY usergroup
    ADD CONSTRAINT usergroup_pkey PRIMARY KEY (usergroupid);


--
-- TOC entry 3700 (class 2606 OID 20733)
-- Name: users_usergroups_pkey; Type: CONSTRAINT; Schema: sensorweb2; Owner: postgres
--

ALTER TABLE ONLY users_usergroups
    ADD CONSTRAINT users_usergroups_pkey PRIMARY KEY (userid, usergroupid);


--
-- TOC entry 3643 (class 1259 OID 20734)
-- Name: observation_in1; Type: INDEX; Schema: sensorweb2; Owner: postgres
--

CREATE UNIQUE INDEX observation_in1 ON observation USING btree (time_stamp, series_pkid);


--
-- TOC entry 3644 (class 1259 OID 20735)
-- Name: observation_in2; Type: INDEX; Schema: sensorweb2; Owner: postgres
--

CREATE INDEX observation_in2 ON observation USING btree (series_pkid, date_part('year'::text, time_stamp));


--
-- TOC entry 3740 (class 2620 OID 20736)
-- Name: observation_del_to_series; Type: TRIGGER; Schema: sensorweb2; Owner: postgres
--

CREATE TRIGGER observation_del_to_series AFTER DELETE ON observation FOR EACH ROW EXECUTE PROCEDURE observation_del_to_series();


--
-- TOC entry 3741 (class 2620 OID 20737)
-- Name: observation_ins_upd_to_series; Type: TRIGGER; Schema: sensorweb2; Owner: postgres
--

CREATE TRIGGER observation_ins_upd_to_series AFTER INSERT OR UPDATE ON observation FOR EACH ROW EXECUTE PROCEDURE observation_ins_upd_to_series();


--
-- TOC entry 3742 (class 2620 OID 20738)
-- Name: observation_sync_derived; Type: TRIGGER; Schema: sensorweb2; Owner: postgres
--

CREATE TRIGGER observation_sync_derived AFTER INSERT OR DELETE OR UPDATE ON observation FOR EACH ROW EXECUTE PROCEDURE observation_sync_derived();


--
-- TOC entry 3701 (class 2606 OID 20739)
-- Name: category_i18n_category_pkid_fkey; Type: FK CONSTRAINT; Schema: sensorweb2; Owner: postgres
--

ALTER TABLE ONLY category_i18n
    ADD CONSTRAINT category_i18n_category_pkid_fkey FOREIGN KEY (category_pkid) REFERENCES category(pkid);


--
-- TOC entry 3717 (class 2606 OID 20886)
-- Name: category_pkid; Type: FK CONSTRAINT; Schema: sensorweb2; Owner: postgres
--

ALTER TABLE ONLY series
    ADD CONSTRAINT category_pkid FOREIGN KEY (category_pkid) REFERENCES category(pkid);


--
-- TOC entry 3704 (class 2606 OID 20744)
-- Name: feature_of_interest_i18n_feature_of_interest_pkid_fkey; Type: FK CONSTRAINT; Schema: sensorweb2; Owner: postgres
--

ALTER TABLE ONLY feature_of_interest_i18n
    ADD CONSTRAINT feature_of_interest_i18n_feature_of_interest_pkid_fkey FOREIGN KEY (feature_of_interest_pkid) REFERENCES feature_of_interest(pkid);


--
-- TOC entry 3720 (class 2606 OID 20901)
-- Name: feature_of_interest_pkid; Type: FK CONSTRAINT; Schema: sensorweb2; Owner: postgres
--

ALTER TABLE ONLY series
    ADD CONSTRAINT feature_of_interest_pkid FOREIGN KEY (feature_of_interest_pkid) REFERENCES feature_of_interest(pkid);


--
-- TOC entry 3739 (class 2606 OID 20931)
-- Name: fk1lva8l1bmqtf5c0nvogxotj9s; Type: FK CONSTRAINT; Schema: sensorweb2; Owner: postgres
--

ALTER TABLE ONLY users_usergroups
    ADD CONSTRAINT fk1lva8l1bmqtf5c0nvogxotj9s FOREIGN KEY (userid) REFERENCES user_(userid);


--
-- TOC entry 3738 (class 2606 OID 20926)
-- Name: fksu6516x6ku0k09d8eiufqry7a; Type: FK CONSTRAINT; Schema: sensorweb2; Owner: postgres
--

ALTER TABLE ONLY users_usergroups
    ADD CONSTRAINT fksu6516x6ku0k09d8eiufqry7a FOREIGN KEY (usergroupid) REFERENCES usergroup(usergroupid);


--
-- TOC entry 3705 (class 2606 OID 20749)
-- Name: observation_series_pkid_fkey; Type: FK CONSTRAINT; Schema: sensorweb2; Owner: postgres
--

ALTER TABLE ONLY observation
    ADD CONSTRAINT observation_series_pkid_fkey FOREIGN KEY (series_pkid) REFERENCES series(pkid) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- TOC entry 3706 (class 2606 OID 20754)
-- Name: phenomenon_i18n_phenomenon_pkid_fkey; Type: FK CONSTRAINT; Schema: sensorweb2; Owner: postgres
--

ALTER TABLE ONLY phenomenon_i18n
    ADD CONSTRAINT phenomenon_i18n_phenomenon_pkid_fkey FOREIGN KEY (phenomenon_pkid) REFERENCES phenomenon(pkid);


--
-- TOC entry 3718 (class 2606 OID 20891)
-- Name: phenomenon_pkid; Type: FK CONSTRAINT; Schema: sensorweb2; Owner: postgres
--

ALTER TABLE ONLY series
    ADD CONSTRAINT phenomenon_pkid FOREIGN KEY (phenomenon_pkid) REFERENCES phenomenon(pkid);


--
-- TOC entry 3707 (class 2606 OID 20759)
-- Name: procedure_i18n_procedure_pkid_fkey; Type: FK CONSTRAINT; Schema: sensorweb2; Owner: postgres
--

ALTER TABLE ONLY procedure_i18n
    ADD CONSTRAINT procedure_i18n_procedure_pkid_fkey FOREIGN KEY (procedure_pkid) REFERENCES procedure(pkid);


--
-- TOC entry 3719 (class 2606 OID 20896)
-- Name: procedure_pkid; Type: FK CONSTRAINT; Schema: sensorweb2; Owner: postgres
--

ALTER TABLE ONLY series
    ADD CONSTRAINT procedure_pkid FOREIGN KEY (procedure_pkid) REFERENCES procedure(pkid);


--
-- TOC entry 3708 (class 2606 OID 20764)
-- Name: rule_fkey; Type: FK CONSTRAINT; Schema: sensorweb2; Owner: postgres
--

ALTER TABLE ONLY rule
    ADD CONSTRAINT rule_fkey FOREIGN KEY (series_pkid) REFERENCES series(pkid) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- TOC entry 3703 (class 2606 OID 20871)
-- Name: rule_pkid; Type: FK CONSTRAINT; Schema: sensorweb2; Owner: postgres
--

ALTER TABLE ONLY event
    ADD CONSTRAINT rule_pkid FOREIGN KEY (rule_pkid) REFERENCES rule(pkid);


--
-- TOC entry 3731 (class 2606 OID 20911)
-- Name: rule_pkid; Type: FK CONSTRAINT; Schema: sensorweb2; Owner: postgres
--

ALTER TABLE ONLY subscription
    ADD CONSTRAINT rule_pkid FOREIGN KEY (rule_pkid) REFERENCES rule(pkid);


--
-- TOC entry 3702 (class 2606 OID 20769)
-- Name: rule_pkid_fkey; Type: FK CONSTRAINT; Schema: sensorweb2; Owner: postgres
--

ALTER TABLE ONLY event
    ADD CONSTRAINT rule_pkid_fkey FOREIGN KEY (rule_pkid) REFERENCES rule(pkid) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- TOC entry 3712 (class 2606 OID 20774)
-- Name: series_category_pkid_fkey; Type: FK CONSTRAINT; Schema: sensorweb2; Owner: postgres
--

ALTER TABLE ONLY series
    ADD CONSTRAINT series_category_pkid_fkey FOREIGN KEY (category_pkid) REFERENCES category(pkid) MATCH FULL ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- TOC entry 3722 (class 2606 OID 20779)
-- Name: series_cluster_cluster_pkid; Type: FK CONSTRAINT; Schema: sensorweb2; Owner: postgres
--

ALTER TABLE ONLY series_cluster
    ADD CONSTRAINT series_cluster_cluster_pkid FOREIGN KEY (cluster_pkid) REFERENCES cluster(pkid) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- TOC entry 3723 (class 2606 OID 20784)
-- Name: series_cluster_series_pkid_fkey; Type: FK CONSTRAINT; Schema: sensorweb2; Owner: postgres
--

ALTER TABLE ONLY series_cluster
    ADD CONSTRAINT series_cluster_series_pkid_fkey FOREIGN KEY (series_pkid) REFERENCES series(pkid) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- TOC entry 3724 (class 2606 OID 20789)
-- Name: series_derived_series_pkid_base_fkey; Type: FK CONSTRAINT; Schema: sensorweb2; Owner: postgres
--

ALTER TABLE ONLY series_derived
    ADD CONSTRAINT series_derived_series_pkid_base_fkey FOREIGN KEY (series_pkid_base) REFERENCES series(pkid) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- TOC entry 3725 (class 2606 OID 20794)
-- Name: series_derived_series_pkid_derived_fkey; Type: FK CONSTRAINT; Schema: sensorweb2; Owner: postgres
--

ALTER TABLE ONLY series_derived
    ADD CONSTRAINT series_derived_series_pkid_derived_fkey FOREIGN KEY (series_pkid_derived) REFERENCES series(pkid) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- TOC entry 3713 (class 2606 OID 20799)
-- Name: series_feature_of_interest_pkid_fkey; Type: FK CONSTRAINT; Schema: sensorweb2; Owner: postgres
--

ALTER TABLE ONLY series
    ADD CONSTRAINT series_feature_of_interest_pkid_fkey FOREIGN KEY (feature_of_interest_pkid) REFERENCES feature_of_interest(pkid) MATCH FULL ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- TOC entry 3714 (class 2606 OID 20804)
-- Name: series_phenomenon_pkid_fkey; Type: FK CONSTRAINT; Schema: sensorweb2; Owner: postgres
--

ALTER TABLE ONLY series
    ADD CONSTRAINT series_phenomenon_pkid_fkey FOREIGN KEY (phenomenon_pkid) REFERENCES phenomenon(pkid) MATCH FULL ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- TOC entry 3710 (class 2606 OID 20876)
-- Name: series_pkid; Type: FK CONSTRAINT; Schema: sensorweb2; Owner: postgres
--

ALTER TABLE ONLY rule
    ADD CONSTRAINT series_pkid FOREIGN KEY (series_pkid) REFERENCES series(pkid);


--
-- TOC entry 3715 (class 2606 OID 20809)
-- Name: series_procedure_pkid_fkey; Type: FK CONSTRAINT; Schema: sensorweb2; Owner: postgres
--

ALTER TABLE ONLY series
    ADD CONSTRAINT series_procedure_pkid_fkey FOREIGN KEY (procedure_pkid) REFERENCES procedure(pkid) MATCH FULL ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- TOC entry 3726 (class 2606 OID 20814)
-- Name: series_reference_series_pkid_from_fkey; Type: FK CONSTRAINT; Schema: sensorweb2; Owner: postgres
--

ALTER TABLE ONLY series_reference
    ADD CONSTRAINT series_reference_series_pkid_from_fkey FOREIGN KEY (series_pkid_from) REFERENCES series(pkid) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- TOC entry 3727 (class 2606 OID 20819)
-- Name: series_reference_series_pkid_to_fkey; Type: FK CONSTRAINT; Schema: sensorweb2; Owner: postgres
--

ALTER TABLE ONLY series_reference
    ADD CONSTRAINT series_reference_series_pkid_to_fkey FOREIGN KEY (series_pkid_to) REFERENCES series(pkid) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- TOC entry 3716 (class 2606 OID 20824)
-- Name: series_unit_pkid_fkey; Type: FK CONSTRAINT; Schema: sensorweb2; Owner: postgres
--

ALTER TABLE ONLY series
    ADD CONSTRAINT series_unit_pkid_fkey FOREIGN KEY (unit_pkid) REFERENCES unit(pkid) MATCH FULL ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- TOC entry 3728 (class 2606 OID 20829)
-- Name: subscription_fkey_rule; Type: FK CONSTRAINT; Schema: sensorweb2; Owner: postgres
--

ALTER TABLE ONLY subscription
    ADD CONSTRAINT subscription_fkey_rule FOREIGN KEY (rule_pkid) REFERENCES rule(pkid) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- TOC entry 3729 (class 2606 OID 20834)
-- Name: subscription_fkey_user; Type: FK CONSTRAINT; Schema: sensorweb2; Owner: postgres
--

ALTER TABLE ONLY subscription
    ADD CONSTRAINT subscription_fkey_user FOREIGN KEY (userid) REFERENCES user_(userid) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- TOC entry 3730 (class 2606 OID 20839)
-- Name: subscription_fkey_usergroup; Type: FK CONSTRAINT; Schema: sensorweb2; Owner: postgres
--

ALTER TABLE ONLY subscription
    ADD CONSTRAINT subscription_fkey_usergroup FOREIGN KEY (usergroupid) REFERENCES usergroup(usergroupid) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- TOC entry 3711 (class 2606 OID 20881)
-- Name: trend_code; Type: FK CONSTRAINT; Schema: sensorweb2; Owner: postgres
--

ALTER TABLE ONLY rule
    ADD CONSTRAINT trend_code FOREIGN KEY (trend_code) REFERENCES trend(code);


--
-- TOC entry 3709 (class 2606 OID 20844)
-- Name: trend_code_fkey; Type: FK CONSTRAINT; Schema: sensorweb2; Owner: postgres
--

ALTER TABLE ONLY rule
    ADD CONSTRAINT trend_code_fkey FOREIGN KEY (trend_code) REFERENCES trend(code) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- TOC entry 3734 (class 2606 OID 20849)
-- Name: trend_i18n_fkey; Type: FK CONSTRAINT; Schema: sensorweb2; Owner: postgres
--

ALTER TABLE ONLY trend_i18n
    ADD CONSTRAINT trend_i18n_fkey FOREIGN KEY (trend_code) REFERENCES trend(code);


--
-- TOC entry 3735 (class 2606 OID 20854)
-- Name: unit_i18n_unit_pkid_fkey; Type: FK CONSTRAINT; Schema: sensorweb2; Owner: postgres
--

ALTER TABLE ONLY unit_i18n
    ADD CONSTRAINT unit_i18n_unit_pkid_fkey FOREIGN KEY (unit_pkid) REFERENCES unit(pkid);


--
-- TOC entry 3721 (class 2606 OID 20906)
-- Name: unit_pkid; Type: FK CONSTRAINT; Schema: sensorweb2; Owner: postgres
--

ALTER TABLE ONLY series
    ADD CONSTRAINT unit_pkid FOREIGN KEY (unit_pkid) REFERENCES unit(pkid);


--
-- TOC entry 3733 (class 2606 OID 20921)
-- Name: usergroupid; Type: FK CONSTRAINT; Schema: sensorweb2; Owner: postgres
--

ALTER TABLE ONLY subscription
    ADD CONSTRAINT usergroupid FOREIGN KEY (usergroupid) REFERENCES usergroup(usergroupid);


--
-- TOC entry 3732 (class 2606 OID 20916)
-- Name: userid; Type: FK CONSTRAINT; Schema: sensorweb2; Owner: postgres
--

ALTER TABLE ONLY subscription
    ADD CONSTRAINT userid FOREIGN KEY (userid) REFERENCES user_(userid);


--
-- TOC entry 3736 (class 2606 OID 20859)
-- Name: users_usergroups_fkey_user; Type: FK CONSTRAINT; Schema: sensorweb2; Owner: postgres
--

ALTER TABLE ONLY users_usergroups
    ADD CONSTRAINT users_usergroups_fkey_user FOREIGN KEY (userid) REFERENCES user_(userid) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- TOC entry 3737 (class 2606 OID 20864)
-- Name: users_usergroups_fkey_usergroup; Type: FK CONSTRAINT; Schema: sensorweb2; Owner: postgres
--

ALTER TABLE ONLY users_usergroups
    ADD CONSTRAINT users_usergroups_fkey_usergroup FOREIGN KEY (usergroupid) REFERENCES usergroup(usergroupid) ON UPDATE RESTRICT ON DELETE RESTRICT;


-- Completed on 2016-11-30 15:42:32 CET

--
-- PostgreSQL database dump complete
--

